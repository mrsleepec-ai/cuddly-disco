Положите сюда шрифт с поддержкой кириллицы, например:
- NotoSans-Regular.ttf

И убедитесь, что в `pubspec.yaml` раздел `assets` указывает на `assets/fonts/`.
