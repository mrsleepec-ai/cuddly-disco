import 'dart:io';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'models.dart';

class PdfService {
  Future<pw.Font> _loadCyrillicFont() async {
    try {
      final file = File('assets/fonts/NotoSans-Regular.ttf');
      if (await file.exists()) {
        final bytes = await file.readAsBytes();
        return pw.Font.ttf(bytes.buffer.asByteData());
      }
    } catch (_) {}
    return pw.Font.helvetica();
  }

  Future<File> _saveDoc(pw.Document doc, String base) async {
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/$base.pdf');
    await f.writeAsBytes(await doc.save());
    return f;
  }

  List<_RowItem> _flatten(Task task) {
    final list = <_RowItem>[];
    // top-level first
    for (final s in task.subtasks) {
      list.add(_RowItem(title: s.title, s: s));
    }
    // then folders
    for (final f in task.folders) {
      for (final s in f.subtasks) {
        list.add(_RowItem(title: '[${f.title}] ${s.title}', s: s));
      }
    }
    return list;
  }

  Future<File> generateChecklist(Task task, {int days = 14}) async {
    final font = await _loadCyrillicFont();
    final doc = pw.Document();
    final start = DateTime(task.createdAt.year, task.createdAt.month, task.createdAt.day);
    final dates = List.generate(days, (i) => start.add(Duration(days: i)));
    final fmt = DateFormat('dd.MM');

    final headers = <String>['Подзадача', ...dates.map(fmt.format)];
    final rows = _flatten(task).isEmpty
        ? [[task.title, ...List.filled(dates.length, '')]]
        : _flatten(task).map((e) => [e.title, ...List.filled(dates.length, '')]).toList();

    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4.landscape,
      build: (ctx) => [
        pw.Text('Чек-лист: ${task.title}', style: pw.TextStyle(font: font, fontSize: 20)),
        pw.SizedBox(height: 8),
        pw.Table.fromTextArray(
          headerStyle: pw.TextStyle(font: font, fontSize: 10, fontWeight: pw.FontWeight.bold),
          cellStyle: pw.TextStyle(font: font, fontSize: 10),
          headers: headers,
          data: rows,
          headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
          cellAlignment: pw.Alignment.centerLeft,
          border: pw.TableBorder.all(width: 0.5, color: PdfColors.grey500),
        ),
        pw.SizedBox(height: 6),
        pw.Text('Дата создания: ${DateFormat('dd.MM.yyyy').format(task.createdAt)}',
            style: pw.TextStyle(font: font, fontSize: 9, color: PdfColors.grey700)),
      ],
    ));
    return _saveDoc(doc, 'checklist_${_safe(task.title)}');
  }

  Future<File> generateFullReport(Task task) async {
    final font = await _loadCyrillicFont();
    final doc = pw.Document();
    final items = _flatten(task);

    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      build: (ctx) => [
        pw.Text(task.title, style: pw.TextStyle(font: font, fontSize: 24)),
        pw.SizedBox(height: 10),
        ...items.map((e) => _subtaskSection(font, e.title, e.s)),
      ],
    ));
    return _saveDoc(doc, 'report_${_safe(task.title)}');
  }

  pw.Widget _subtaskSection(pw.Font font, String title, Subtask s) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text('• $title',
            style: pw.TextStyle(font: font, fontSize: 14, fontWeight: pw.FontWeight.bold)),
        if (s.note.trim().isNotEmpty)
          pw.Padding(
            padding: const pw.EdgeInsets.only(top: 4, bottom: 6),
            child: pw.Text(s.note, style: pw.TextStyle(font: font, fontSize: 11)),
          ),
        if (s.attachments.isNotEmpty)
          pw.Wrap(
            spacing: 8,
            runSpacing: 8,
            children: s.attachments.map((a) {
              if (a.mime.startsWith('image/')) {
                try {
                  final bytes = File(a.path).readAsBytesSync();
                  return pw.Container(
                    width: 160, height: 160,
                    child: pw.Image(pw.MemoryImage(bytes), fit: pw.BoxFit.cover),
                  );
                } catch (_) {
                  return pw.Text('Не удалось загрузить: ${a.path}',
                      style: pw.TextStyle(font: font, fontSize: 9, color: PdfColors.red));
                }
              } else {
                return pw.Text('Вложение: ${a.path}',
                    style: pw.TextStyle(font: font, fontSize: 10, color: PdfColors.blue));
              }
            }).toList(),
          ),
        pw.SizedBox(height: 12),
      ],
    );
  }

  String _safe(String s) => s.replaceAll(RegExp(r'[^a-zA-Z0-9а-яА-Я _-]'), '_');
}

class _RowItem {
  final String title;
  final Subtask s;
  _RowItem({required this.title, required this.s});
}
