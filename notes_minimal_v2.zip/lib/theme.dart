import 'package:flutter/material.dart';

ThemeData buildTheme() {
  final base = ThemeData(
    useMaterial3: true,
    colorSchemeSeed: const Color(0xFF4C6FFF),
    brightness: Brightness.light,
  );
  return base.copyWith(
    scaffoldBackgroundColor: const Color(0xFFF8F9FB),
    appBarTheme: const AppBarTheme(centerTitle: false, elevation: 0),
    listTileTheme: const ListTileThemeData(visualDensity: VisualDensity.compact),
  );
}
