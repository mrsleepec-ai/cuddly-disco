import 'dart:convert';

class Attachment {
  final String id;
  final String path;
  final String mime;
  Attachment({required this.id, required this.path, required this.mime});

  factory Attachment.fromJson(Map<String, dynamic> j) =>
      Attachment(id: j['id'], path: j['path'], mime: j['mime']);
  Map<String, dynamic> toJson() => {'id': id, 'path': path, 'mime': mime};
}

class Subtask {
  final String id;
  String title;
  String note;
  bool done;
  List<Attachment> attachments;
  List<SubtaskFolder> folders; // for future deeper nesting
  Subtask({
    required this.id,
    required this.title,
    this.note = '',
    this.done = false,
    List<Attachment>? attachments,
    List<SubtaskFolder>? folders,
  })  : attachments = attachments ?? [],
        folders = folders ?? [];

  factory Subtask.fromJson(Map<String, dynamic> j) => Subtask(
        id: j['id'],
        title: j['title'],
        note: j['note'] ?? '',
        done: j['done'] ?? false,
        attachments: (j['attachments'] as List? ?? [])
            .map((e) => Attachment.fromJson(e))
            .toList(),
        folders: (j['folders'] as List? ?? [])
            .map((e) => SubtaskFolder.fromJson(e))
            .toList(),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'note': note,
        'done': done,
        'attachments': attachments.map((e) => e.toJson()).toList(),
        'folders': folders.map((e) => e.toJson()).toList(),
      };
}

class SubtaskFolder {
  final String id;
  String title;
  List<Subtask> subtasks;
  SubtaskFolder({required this.id, required this.title, List<Subtask>? subtasks})
      : subtasks = subtasks ?? [];

  factory SubtaskFolder.fromJson(Map<String, dynamic> j) => SubtaskFolder(
        id: j['id'],
        title: j['title'],
        subtasks:
            (j['subtasks'] as List? ?? []).map((e) => Subtask.fromJson(e)).toList(),
      );

  Map<String, dynamic> toJson() =>
      {'id': id, 'title': title, 'subtasks': subtasks.map((e) => e.toJson()).toList()};
}

class Task {
  final String id;
  String title;
  DateTime createdAt;
  bool done;
  List<Subtask> subtasks; // top-level subtasks
  List<SubtaskFolder> folders; // folders with subtasks
  Task({
    required this.id,
    required this.title,
    required this.createdAt,
    this.done = false,
    List<Subtask>? subtasks,
    List<SubtaskFolder>? folders,
  })  : subtasks = subtasks ?? [],
        folders = folders ?? [];

  /// All subtasks including ones inside folders
  List<Subtask> get allSubtasks {
    final list = <Subtask>[];
    list.addAll(subtasks);
    for (final f in folders) {
      list.addAll(f.subtasks);
    }
    return list;
  }

  bool get hasAnySubtasks => allSubtasks.isNotEmpty;
  bool get allSubtasksDone => hasAnySubtasks && allSubtasks.every((s) => s.done);

  factory Task.fromJson(Map<String, dynamic> j) => Task(
        id: j['id'],
        title: j['title'],
        createdAt: DateTime.parse(j['createdAt']),
        done: j['done'] ?? false,
        subtasks:
            (j['subtasks'] as List? ?? []).map((e) => Subtask.fromJson(e)).toList(),
        folders: (j['folders'] as List? ?? [])
            .map((e) => SubtaskFolder.fromJson(e))
            .toList(),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'createdAt': createdAt.toIso8601String(),
        'done': done,
        'subtasks': subtasks.map((e) => e.toJson()).toList(),
        'folders': folders.map((e) => e.toJson()).toList(),
      };
}

class AppData {
  List<Task> tasks;
  AppData({List<Task>? tasks}) : tasks = tasks ?? [];

  List<Task> get active => tasks.where((t) => !t.done).toList();
  List<Task> get completed => tasks.where((t) => t.done).toList();

  factory AppData.fromJson(Map<String, dynamic> j) => AppData(
        tasks:
            (j['tasks'] as List? ?? []).map((e) => Task.fromJson(e)).toList(),
      );

  Map<String, dynamic> toJson() => {'tasks': tasks.map((e) => e.toJson()).toList()};

  String encode() => jsonEncode(toJson());
  factory AppData.decode(String s) => AppData.fromJson(jsonDecode(s));
}
