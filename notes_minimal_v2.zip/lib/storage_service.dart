import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'models.dart';

class StorageService {
  static const _fileName = 'app_db.json';
  Future<File> _file() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/$_fileName');
  }

  Future<AppData> load() async {
    try {
      final f = await _file();
      if (!(await f.exists())) return AppData();
      final content = await f.readAsString();
      return AppData.decode(content);
    } catch (_) {
      return AppData();
    }
  }

  Future<void> save(AppData data) async {
    final f = await _file();
    await f.writeAsString(data.encode());
  }
}
