import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models.dart';
import '../storage_service.dart';
import 'app_state.dart';

final storageProvider = Provider((ref) => StorageService());
final appControllerProvider =
    StateNotifierProvider<AppController, AppState?>((ref) => AppController(ref));

class AppController extends StateNotifier<AppState?> {
  final Ref ref;
  AppController(this.ref) : super(null) {
    _init();
  }

  Future<void> _init() async {
    final s = ref.read(storageProvider);
    final data = await s.load();
    state = AppState(data);
  }

  Future<void> _persist() async {
    final s = ref.read(storageProvider);
    await s.save(state!.data);
  }

  // ЗАДАЧИ
  Future<void> addTask(String title) async {
    if (state == null || title.trim().isEmpty) return;
    state!.data.tasks.add(newTask(title));
    state = state!.copy();
    await _persist();
  }

  Future<void> renameTask(Task task, String newTitle) async {
    task.title = newTitle.trim();
    state = state!.copy();
    await _persist();
  }

  Future<void> deleteTask(Task task) async {
    state!.data.tasks.removeWhere((t) => t.id == task.id);
    state = state!.copy();
    await _persist();
  }

  Future<void> toggleTaskDone(Task task, bool done) async {
    task.done = done;
    state = state!.copy();
    await _persist();
  }

  void _autoCompleteTaskIfNeeded(Task task) {
    if (task.allSubtasksDone) {
      task.done = true;
    } else if (!task.hasAnySubtasks && task.done) {
      // if no subtasks exist, keep manual control
    } else if (task.done && !task.allSubtasksDone) {
      // if user marked task done but not all subtasks done, keep as is
    }
  }

  // ПОДЗАДАЧИ (верхний уровень)
  Future<void> addSubtask(Task task, String title) async {
    if (title.trim().isEmpty) return;
    task.subtasks.add(newSubtask(title));
    _autoCompleteTaskIfNeeded(task);
    state = state!.copy();
    await _persist();
  }

  Future<void> toggleSubtask(Subtask s, Task task, bool done) async {
    s.done = done;
    _autoCompleteTaskIfNeeded(task);
    state = state!.copy();
    await _persist();
  }

  Future<void> renameSubtask(Subtask s, String title) async {
    s.title = title.trim();
    state = state!.copy();
    await _persist();
  }

  Future<void> deleteSubtask(Task t, Subtask s) async {
    t.subtasks.removeWhere((x) => x.id == s.id);
    // also try remove from folders (in case)
    for (final f in t.folders) {
      f.subtasks.removeWhere((x) => x.id == s.id);
    }
    _autoCompleteTaskIfNeeded(t);
    state = state!.copy();
    await _persist();
  }

  // ПАПКИ
  Future<void> addFolder(Task task, String title) async {
    if (title.trim().isEmpty) return;
    task.folders.add(newFolder(title));
    state = state!.copy();
    await _persist();
  }

  Future<void> moveSubtaskToFolder(Task task, Subtask s, SubtaskFolder folder) async {
    task.subtasks.removeWhere((x) => x.id == s.id);
    // also pull from any other folder
    for (final f in task.folders) {
      f.subtasks.removeWhere((x) => x.id == s.id);
    }
    folder.subtasks.add(s);
    _autoCompleteTaskIfNeeded(task);
    state = state!.copy();
    await _persist();
  }

  // Подзадачи внутри папки
  Future<void> addSubtaskInFolder(Task task, SubtaskFolder folder, String title) async {
    if (title.trim().isEmpty) return;
    folder.subtasks.add(newSubtask(title));
    _autoCompleteTaskIfNeeded(task);
    state = state!.copy();
    await _persist();
  }

  Future<void> deleteSubtaskFromFolder(Task task, SubtaskFolder folder, Subtask s) async {
    folder.subtasks.removeWhere((x) => x.id == s.id);
    _autoCompleteTaskIfNeeded(task);
    state = state!.copy();
    await _persist();
  }

  // Вложения
  Future<void> addAttachment(Subtask s, Attachment a) async {
    s.attachments.add(a);
    state = state!.copy();
    await _persist();
  }

  Future<void> removeAttachment(Subtask s, Attachment a) async {
    s.attachments.removeWhere((x) => x.id == a.id);
    state = state!.copy();
    await _persist();
  }
}
