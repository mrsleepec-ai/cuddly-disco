import 'package:uuid/uuid.dart';
import '../models.dart';

final _uuid = Uuid();

class AppState {
  AppData data;
  AppState(this.data);
  AppState copy() => AppState(AppData(tasks: [...data.tasks]));
}

Task newTask(String title) => Task(
      id: _uuid.v4(),
      title: title.trim(),
      createdAt: DateTime.now(),
      done: false,
    );

Subtask newSubtask(String title) => Subtask(id: _uuid.v4(), title: title.trim());
SubtaskFolder newFolder(String title) => SubtaskFolder(id: _uuid.v4(), title: title.trim());
