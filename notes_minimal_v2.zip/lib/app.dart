import 'package:flutter/material.dart';
import 'theme.dart';
import 'features/home/home_page.dart';

class AppRoot extends StatelessWidget {
  const AppRoot({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Minimal Notes',
      theme: buildTheme(),
      home: const HomePage(),
    );
  }
}
