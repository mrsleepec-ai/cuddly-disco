import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../state/app_controller.dart';
import '../../models.dart';
import '../task/task_page.dart';
import '../task/widgets/task_tile.dart';

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});
  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> with TickerProviderStateMixin {
  late final TabController _tab;
  final _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(appControllerProvider);
    final ctrl = ref.read(appControllerProvider.notifier);

    if (state == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Задачи'),
        bottom: TabBar(
          controller: _tab,
          tabs: const [Tab(text: 'Активные'), Tab(text: 'Выполненные')],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          _taskList(state.data.active),
          _taskList(state.data.completed),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _controller,
                  decoration: const InputDecoration(
                    hintText: 'Новая задача...',
                    filled: true,
                    border: OutlineInputBorder(borderSide: BorderSide.none),
                  ),
                  onSubmitted: (v) async {
                    await ctrl.addTask(v);
                    _controller.clear();
                  },
                ),
              ),
              const SizedBox(width: 8),
              FilledButton(
                onPressed: () async {
                  await ctrl.addTask(_controller.text);
                  _controller.clear();
                },
                child: const Icon(Icons.add),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _taskList(List<Task> tasks) {
    if (tasks.isEmpty) {
      return const Center(child: Text('Пока пусто'));
    }
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 90),
      itemCount: tasks.length,
      itemBuilder: (c, i) => TaskTile(task: tasks[i]),
    );
  }
}
