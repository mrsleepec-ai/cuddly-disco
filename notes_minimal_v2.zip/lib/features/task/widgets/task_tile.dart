import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../models.dart';
import '../../../state/app_controller.dart';
import '../../task/task_page.dart';
import '../../../pdf_service.dart';
import 'package:share_plus/share_plus.dart';

class TaskTile extends ConsumerWidget {
  final Task task;
  const TaskTile({super.key, required this.task});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ctrl = ref.read(appControllerProvider.notifier);
    final pdf = PdfService();

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: ListTile(
        leading: Checkbox(
          value: task.done,
          onChanged: (v) => ctrl.toggleTaskDone(task, v ?? false),
        ),
        title: Text(task.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text('Подзадач: ${task.subtasks.length}', style: const TextStyle(color: Colors.black54)),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => TaskPage(task: task))),
        trailing: PopupMenuButton<String>(
          onSelected: (k) async {
            switch (k) {
              case 'rename':
                final name = await _prompt(context, 'Переименовать', task.title);
                if (name != null) await ctrl.renameTask(task, name);
                break;
              case 'delete':
                await ctrl.deleteTask(task);
                break;
              case 'pdf_check':
                final days = await _pickDays(context);
                final file = await pdf.generateChecklist(task, days: days ?? 14);
                await Share.shareXFiles([XFile(file.path)]);
                break;
              case 'pdf_full':
                final file = await pdf.generateFullReport(task);
                await Share.shareXFiles([XFile(file.path)]);
                break;
            }
          },
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'rename', child: Text('Переименовать')),
            PopupMenuItem(value: 'delete', child: Text('Удалить')),
            PopupMenuDivider(),
            PopupMenuItem(value: 'pdf_check', child: Text('Экспорт → Чек-лист (PDF)')),
            PopupMenuItem(value: 'pdf_full', child: Text('Экспорт → Полный отчёт (PDF)')),
          ],
        ),
      ),
    );
  }

  Future<String?> _prompt(BuildContext context, String title, String initial) async {
    final ctrl = TextEditingController(text: initial);
    return showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: TextField(controller: ctrl, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.pop(context, ctrl.text), child: const Text('OK')),
        ],
      ),
    );
  }

  Future<int?> _pickDays(BuildContext context) async {
    int val = 14;
    return showDialog<int>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Дни для чек-листа'),
        content: StatefulBuilder(builder: (c, setState) {
          return Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('Сколько дней со дня создания добавить столбцами?'),
            const SizedBox(height: 8),
            DropdownButton<int>(
              value: val,
              items: const [
                DropdownMenuItem(value: 7, child: Text('7')),
                DropdownMenuItem(value: 14, child: Text('14')),
                DropdownMenuItem(value: 30, child: Text('30')),
              ],
              onChanged: (v) => setState(() => val = v ?? 14),
            ),
          ]);
        }),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.pop(context, val), child: const Text('OK')),
        ],
      ),
    );
  }
}
