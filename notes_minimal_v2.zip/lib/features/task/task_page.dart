import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models.dart';
import '../../state/app_controller.dart';
import '../folders/move_to_folder_sheet.dart';
import '../subtask/subtask_page.dart';
import '../folders/folder_page.dart';

class TaskPage extends ConsumerStatefulWidget {
  final Task task;
  const TaskPage({super.key, required this.task});

  @override
  ConsumerState<TaskPage> createState() => _TaskPageState();
}

class _TaskPageState extends ConsumerState<TaskPage> {
  final _subCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final ctrl = ref.read(appControllerProvider.notifier);
    final task = widget.task;

    return Scaffold(
      appBar: AppBar(title: Text(task.title)),
      body: Column(
        children: [
          _sectionHeader(
            'Папки',
            action: IconButton(
              icon: const Icon(Icons.create_new_folder_outlined),
              onPressed: () async {
                final name = await _prompt(context, 'Новая папка', '');
                if (name != null) await ctrl.addFolder(task, name);
              },
            ),
          ),
          _folders(task),
          _sectionHeader('Подзадачи'),
          Expanded(child: _subtasks(task)),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
              child: Row(children: [
                Expanded(
                  child: TextField(
                    controller: _subCtrl,
                    decoration: const InputDecoration(
                      hintText: 'Новая подзадача...',
                      filled: true,
                      border: OutlineInputBorder(borderSide: BorderSide.none),
                    ),
                    onSubmitted: (v) async {
                      await ctrl.addSubtask(task, v);
                      _subCtrl.clear();
                    },
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: () async {
                    await ctrl.addSubtask(task, _subCtrl.text);
                    _subCtrl.clear();
                  },
                  child: const Icon(Icons.add),
                ),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _folders(Task task) {
    if (task.folders.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Align(alignment: Alignment.centerLeft, child: Text('Нет папок')),
      );
    }
    return SizedBox(
      height: 100,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        scrollDirection: Axis.horizontal,
        itemBuilder: (c, i) {
          final f = task.folders[i];
          return DragTarget<Subtask>(
            onAccept: (s) =>
                ref.read(appControllerProvider.notifier).moveSubtaskToFolder(task, s, f),
            builder: (context, candidate, rejected) => InkWell(
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => FolderPage(task: task, folder: f)),
              ),
              child: Container(
                width: 160,
                decoration: BoxDecoration(
                  color: candidate.isNotEmpty ? Colors.blue.shade50 : Colors.white,
                  border: Border.all(color: Colors.black12),
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.folder_outlined),
                    const SizedBox(height: 6),
                    Text(f.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                    Text('${f.subtasks.length} шт.', style: const TextStyle(fontSize: 11)),
                    const Spacer(),
                    const Text('Тап — открыть', style: TextStyle(fontSize: 10, color: Colors.black54)),
                  ],
                ),
              ),
            ),
          );
        },
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemCount: task.folders.length,
      ),
    );
  }

  Widget _subtasks(Task task) {
    final ctrl = ref.read(appControllerProvider.notifier);
    if (task.subtasks.isEmpty) {
      return const Center(child: Text('Подзадач пока нет'));
    }
    return ListView.builder(
      itemCount: task.subtasks.length,
      itemBuilder: (c, i) {
        final s = task.subtasks[i];
        return LongPressDraggable<Subtask>(
          data: s,
          feedback: Material(
            color: Colors.transparent,
            child: Opacity(opacity: .8, child: Chip(label: Text(s.title))),
          ),
          child: Card(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: ListTile(
              leading: Checkbox(
                value: s.done,
                onChanged: (v) => ctrl.toggleSubtask(s, task, v ?? false),
              ),
              title: Text(s.title),
              subtitle: Text('Вложений: ${s.attachments.length}'),
              onTap: () => Navigator.of(c).push(
                MaterialPageRoute(builder: (_) => SubtaskPage(task: task, subtask: s)),
              ),
              trailing: PopupMenuButton<String>(
                onSelected: (k) async {
                  switch (k) {
                    case 'rename':
                      final name = await _prompt(c, 'Переименовать', s.title);
                      if (name != null) await ctrl.renameSubtask(s, name);
                      break;
                    case 'delete':
                      await ctrl.deleteSubtask(task, s);
                      break;
                    case 'move':
                      await showModalBottomSheet(
                        context: c,
                        builder: (_) => MoveToFolderSheet(task: task, subtask: s),
                      );
                      break;
                  }
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'rename', child: Text('Переименовать')),
                  PopupMenuItem(value: 'move', child: Text('Переместить в папку')),
                  PopupMenuItem(value: 'delete', child: Text('Удалить')),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _sectionHeader(String title, {Widget? action}) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
      child: Row(
        children: [
          Text(title, style: const TextStyle(fontSize: 13, color: Colors.black54)),
          const Spacer(),
          if (action != null) action,
        ],
      ),
    );
  }

  Future<String?> _prompt(BuildContext c, String title, String initial) async {
    final ctrl = TextEditingController(text: initial);
    return showDialog<String>(
      context: c,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: TextField(controller: ctrl, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.pop(c, ctrl.text), child: const Text('OK')),
        ],
      ),
    );
  }
}
