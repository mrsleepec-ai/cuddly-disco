import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';
import '../../models.dart';
import '../../state/app_controller.dart';
import 'widgets/attachment_grid.dart';

class SubtaskPage extends ConsumerStatefulWidget {
  final Task task;
  final Subtask subtask;
  const SubtaskPage({super.key, required this.task, required this.subtask});

  @override
  ConsumerState<SubtaskPage> createState() => _SubtaskPageState();
}

class _SubtaskPageState extends ConsumerState<SubtaskPage> {
  final _noteCtrl = TextEditingController();
  final _uuid = const Uuid();

  @override
  void initState() {
    super.initState();
    _noteCtrl.text = widget.subtask.note;
  }

  @override
  Widget build(BuildContext context) {
    final ctrl = ref.read(appControllerProvider.notifier);
    final s = widget.subtask;

    return Scaffold(
      appBar: AppBar(
        title: Text(s.title),
        actions: [
          IconButton(
            icon: const Icon(Icons.save_outlined),
            onPressed: () async {
              s.note = _noteCtrl.text;
              await ctrl.renameSubtask(s, s.title);
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Сохранено')),
                );
              }
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          const Text('Заметка', style: TextStyle(fontSize: 13, color: Colors.black54)),
          const SizedBox(height: 6),
          TextField(
            controller: _noteCtrl,
            maxLines: null,
            decoration: const InputDecoration(
              hintText: 'Напишите заметку...',
              filled: true,
              border: OutlineInputBorder(borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 16),
          const Text('Вложения', style: TextStyle(fontSize: 13, color: Colors.black54)),
          const SizedBox(height: 6),
          AttachmentGrid(subtask: s),
        ],
      ),
      floatingActionButton: _fab(context, ctrl, s),
    );
  }

  Widget _fab(BuildContext c, AppController ctrl, Subtask s) {
    return PopupMenuButton<String>(
      icon: const Icon(Icons.attach_file),
      onSelected: (k) async {
        switch (k) {
          case 'camera':
            final x = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 85);
            if (x != null) {
              await ctrl.addAttachment(
                s,
                Attachment(id: _uuid.v4(), path: x.path, mime: 'image/jpeg'),
              );
            }
            break;
          case 'gallery':
            final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85);
            if (x != null) {
              await ctrl.addAttachment(
                s,
                Attachment(id: _uuid.v4(), path: x.path, mime: 'image/jpeg'),
              );
            }
            break;
          case 'files':
            final res = await FilePicker.platform.pickFiles(allowMultiple: false);
            if (res != null && res.files.single.path != null) {
              final p = res.files.single.path!;
              final mime = _guessMime(p);
              await ctrl.addAttachment(s, Attachment(id: _uuid.v4(), path: p, mime: mime));
            }
            break;
        }
      },
      itemBuilder: (_) => const [
        PopupMenuItem(value: 'camera', child: Text('Снять фото')),
        PopupMenuItem(value: 'gallery', child: Text('Из медиатеки')),
        PopupMenuItem(value: 'files', child: Text('Из файлов')),
      ],
    );
  }

  String _guessMime(String path) {
    final ext = path.toLowerCase().split('.').last;
    if (['jpg', 'jpeg', 'png', 'gif', 'heic', 'bmp', 'webp'].contains(ext)) return 'image/$ext';
    return 'application/octet-stream';
  }
}
