import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../models.dart';
import '../../../state/app_controller.dart';

class AttachmentGrid extends ConsumerWidget {
  final Subtask subtask;
  const AttachmentGrid({super.key, required this.subtask});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (subtask.attachments.isEmpty) {
      return const Text('Нет вложений');
    }

    final ctrl = ref.read(appControllerProvider.notifier);

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: subtask.attachments.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3, mainAxisSpacing: 6, crossAxisSpacing: 6, childAspectRatio: 1,
      ),
      itemBuilder: (c, i) {
        final a = subtask.attachments[i];
        final isImage = a.mime.startsWith('image/');
        return Stack(
          fit: StackFit.expand,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: isImage
                  ? Image.file(File(a.path), fit: BoxFit.cover)
                  : Container(
                      color: Colors.grey.shade200,
                      child: const Center(child: Icon(Icons.insert_drive_file_outlined)),
                    ),
            ),
            Positioned(
              right: 4,
              top: 4,
              child: InkWell(
                onTap: () => ctrl.removeAttachment(subtask, a),
                child: CircleAvatar(
                  radius: 12,
                  backgroundColor: Colors.black54,
                  child: const Icon(Icons.close, size: 16, color: Colors.white),
                ),
              ),
            )
          ],
        );
      },
    );
  }
}
