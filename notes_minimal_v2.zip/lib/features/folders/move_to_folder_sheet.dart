import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models.dart';
import '../../state/app_controller.dart';

class MoveToFolderSheet extends ConsumerWidget {
  final Task task;
  final Subtask subtask;
  const MoveToFolderSheet({super.key, required this.task, required this.subtask});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ctrl = ref.read(appControllerProvider.notifier);
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Переместить в папку', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          if (task.folders.isEmpty) const Text('Папок нет'),
          ...task.folders.map((f) => ListTile(
                leading: const Icon(Icons.folder_outlined),
                title: Text(f.title),
                onTap: () async {
                  await ctrl.moveSubtaskToFolder(task, subtask, f);
                  // ignore: use_build_context_synchronously
                  Navigator.pop(context);
                },
              )),
        ]),
      ),
    );
  }
}
