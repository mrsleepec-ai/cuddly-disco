import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models.dart';
import '../../state/app_controller.dart';
import '../subtask/subtask_page.dart';

class FolderPage extends ConsumerStatefulWidget {
  final Task task;
  final SubtaskFolder folder;
  const FolderPage({super.key, required this.task, required this.folder});

  @override
  ConsumerState<FolderPage> createState() => _FolderPageState();
}

class _FolderPageState extends ConsumerState<FolderPage> {
  final _subCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final ctrl = ref.read(appControllerProvider.notifier);
    final folder = widget.folder;
    final task = widget.task;

    return Scaffold(
      appBar: AppBar(
        title: Text(folder.title),
      ),
      body: Column(
        children: [
          Expanded(
            child: folder.subtasks.isEmpty
                ? const Center(child: Text('Подзадач пока нет'))
                : ListView.builder(
                    itemCount: folder.subtasks.length,
                    itemBuilder: (c, i) {
                      final s = folder.subtasks[i];
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        child: ListTile(
                          leading: Checkbox(
                            value: s.done,
                            onChanged: (v) => ctrl.toggleSubtask(s, task, v ?? false),
                          ),
                          title: Text(s.title),
                          subtitle: Text('Вложений: ${s.attachments.length}'),
                          onTap: () => Navigator.of(c).push(
                            MaterialPageRoute(builder: (_) => SubtaskPage(task: task, subtask: s)),
                          ),
                          trailing: PopupMenuButton<String>(
                            onSelected: (k) async {
                              switch (k) {
                                case 'rename':
                                  final name = await _prompt(c, 'Переименовать', s.title);
                                  if (name != null) await ctrl.renameSubtask(s, name);
                                  break;
                                case 'delete':
                                  await ctrl.deleteSubtaskFromFolder(task, folder, s);
                                  break;
                              }
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(value: 'rename', child: Text('Переименовать')),
                              PopupMenuItem(value: 'delete', child: Text('Удалить')),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
              child: Row(children: [
                Expanded(
                  child: TextField(
                    controller: _subCtrl,
                    decoration: const InputDecoration(
                      hintText: 'Новая подзадача в папке...',
                      filled: true,
                      border: OutlineInputBorder(borderSide: BorderSide.none),
                    ),
                    onSubmitted: (v) async {
                      await ctrl.addSubtaskInFolder(task, folder, v);
                      _subCtrl.clear();
                    },
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: () async {
                    await ctrl.addSubtaskInFolder(task, folder, _subCtrl.text);
                    _subCtrl.clear();
                  },
                  child: const Icon(Icons.add),
                ),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  Future<String?> _prompt(BuildContext c, String title, String initial) async {
    final ctrl = TextEditingController(text: initial);
    return showDialog<String>(
      context: c,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: TextField(controller: ctrl, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.pop(c, ctrl.text), child: const Text('OK')),
        ],
      ),
    );
  }
}
