# Notes Minimal (Flutter)

Простой менеджер заметок/задач в стиле minimal task.

## Быстрый старт
```bash
flutter pub get
# если создаёте проект с нуля:
flutter create .
flutter run -d chrome
```

> **Примечание про шрифт (PDF):** положите `NotoSans-Regular.ttf` (или любой шрифт с кириллицей)
в `assets/fonts/` и обновите `pubspec.yaml`. Без этого PDF будет использовать дефолтный шрифт и кириллица может отображаться некорректно.

## Деплой web на GitHub Pages
1. Залейте репозиторий на GitHub, ветка `main`.
2. В Settings → Pages выберите **Source: GitHub Actions**.
3. Workflow `.github/workflows/deploy-pages.yml` сам соберёт `flutter build web` и задеплоит.

## Структура
- `lib/` — код приложения.
- `.github/workflows/deploy-pages.yml` — деплой web.
- `assets/fonts/` — положите сюда ttf с кириллицей.
