// lib/services/pdf_export.dart (use printing.PdfGoogleFonts)
import 'dart:typed_data';
import 'dart:html' as html;
import 'dart:async';

import 'package:intl/intl.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'package:hive/hive.dart';
import 'package:printing/printing.dart' show PdfGoogleFonts;

import '../models/task.dart';
import '../models/subitem.dart';
import '../models/attachment.dart';

enum PdfVariant { compact, detailed, checklist }

class PdfExporter {
  Future<void> exportTask(String taskId, PdfVariant variant, {int days = 28}) async {
    String phase = "start";
    try {
      final tasks = Hive.box<Task>('tasks');
      final subs = Hive.box<Subitem>('subitems');
      final atts = Hive.box<Attachment>('attachments');

      final task = tasks.get(taskId);
      if (task == null) throw 'Task not found';

      final subitems = subs.values.where((s) => s.taskId == taskId).toList()
        ..sort((a, b) => a.createdAt.compareTo(b.createdAt));

      final attsBySub = <String, List<Attachment>>{};
      for (final s in subitems) {
        attsBySub[s.id] = atts.values.where((a) => a.subitemId == s.id).toList()
          ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
      }

      // Fonts from Google Fonts via printing (works on Web, includes Cyrillic)
      final baseFont = await PdfGoogleFonts.notoSansRegular();
      final boldFont = await PdfGoogleFonts.notoSansBold();

      final doc = pw.Document();
      
final isChecklist = variant == PdfVariant.checklist;
if (isChecklist) {
  // Собираем только отмеченные подзадачи
  final checked = subitems.where((s) => s.type == SubitemType.subtask && (s as dynamic).checked == true).toList()
    ..sort((a,b)=> a.createdAt.compareTo(b.createdAt));

  if (checked.isEmpty) {
    // Нечего экспортировать
    return;
  }

  final foldersById = <String, Subitem>{ for (final s in subitems.where((x)=> x.type == SubitemType.folder)) s.id: s };
  final grouped = <String?, List<Subitem>>{};
  for (final s in checked) {
    grouped.putIfAbsent(s.parentFolderId, ()=> []).add(s);
  }

  final baseFont = await PdfGoogleFonts.notoSansRegular();
  final boldFont = await PdfGoogleFonts.notoSansBold();
  final doc = pw.Document();

  doc.addPage(
    pw.MultiPage(
      pageTheme: _theme(),
      theme: pw.ThemeData.withFont(base: baseFont, bold: boldFont),
      build: (ctx) {
        final widgets = <pw.Widget>[];
        widgets.add(pw.Header(level: 0, child: pw.Text('Чеклист: ${task.title}', style: pw.TextStyle(fontSize: 22, font: boldFont))));
        widgets.add(pw.Text('Отмеченные подзадачи', style: pw.TextStyle(font: baseFont)));
        widgets.add(pw.SizedBox(height: 8));

        final keys = grouped.keys.toList();
        // Папки (null = корень) в порядке: корень, затем по созданию
        keys.sort((a,b){
          if (a == b) return 0;
          if (a == null) return -1;
          if (b == null) return 1;
          final fa = foldersById[a]!;
          final fb = foldersById[b]!;
          return fa.createdAt.compareTo(fb.createdAt);
        });

        for (final key in keys) {
          final list = grouped[key]!;
          final title = key == null ? '(Без папки)' : foldersById[key]!.title;
          widgets.add(pw.Padding(
            padding: const pw.EdgeInsets.only(top: 6, bottom: 4),
            child: pw.Text(title, style: pw.TextStyle(font: boldFont, fontSize: 14)),
          ));
          for (final s in list) {
            widgets.add(pw.Padding(
              padding: const pw.EdgeInsets.only(left: 8, bottom: 2),
              child: pw.Text('• ' + s.title, style: pw.TextStyle(font: baseFont)),
            ));
          }
          widgets.add(pw.SizedBox(height: 6));
        }

        return widgets;
      },
    ),
  );

  await _savePdf('${_sanitize(task.title)}-checklist.pdf', await doc.save());

  // После экспорта — сбрасываем чекбоксы в 0
  for (final s in checked) {
    final obj = subs.get(s.id);
    if (obj != null) {
      obj.checked = false;
      await obj.save();
    }
  }
  return;
}

      else {
            for (final s in onlySubs) {
              rows.add([s.title, ...List.filled(dates.length, '')]);
            }
          }

          doc.addPage(
            pw.MultiPage(
              pageTheme: _theme(landscape: true),
              theme: pw.ThemeData.withFont(base: baseFont, bold: boldFont),
              build: (ctx) => [
                pw.Header(level: 0, child: pw.Text('Чек-лист: ${task.title}', style: pw.TextStyle(fontSize: 22, font: boldFont))),
                pw.Text('Период: ${DateFormat('dd.MM').format(dates.first)} – ${DateFormat('dd.MM').format(dates.last)}', style: pw.TextStyle(font: baseFont)),
                pw.SizedBox(height: 10),
                pw.Table.fromTextArray(
                  headers: headers,
                  data: rows,
                  headerStyle: pw.TextStyle(font: boldFont),
                  cellStyle: pw.TextStyle(font: baseFont, fontSize: 10),
                  headerDecoration: const pw.BoxDecoration(color: PdfColors.grey200),
                  border: pw.TableBorder.all(color: PdfColors.grey600, width: 0.6),
                  cellAlignment: pw.Alignment.centerLeft,
                ),
              ],
            ),
          );
          generated += span;
        }
      } else {
        doc.addPage(
          pw.MultiPage(
            pageTheme: _theme(),
            theme: pw.ThemeData.withFont(base: baseFont, bold: boldFont),
            build: (ctx) => [
              pw.Header(level: 0, child: pw.Text(task.title, style: pw.TextStyle(fontSize: 24, font: boldFont))),
              pw.Text('Экспорт: ${DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now())}', style: pw.TextStyle(font: baseFont)),
              pw.SizedBox(height: 12),
              ..._detailedBlocks(subitems, attsBySub, baseFont, boldFont),
            ],
          ),
        );
      }

      final Uint8List bytes = await doc.save();
      final url = html.Url.createObjectUrlFromBlob(html.Blob([bytes], 'application/pdf'));
      Future<void>.delayed(const Duration(seconds: 1)).then((_) { try { html.Url.revokeObjectUrl(url); } catch (_) {} });
      html.window.location.href = url;
    } catch (e, st) {
      try { html.window.alert('PDF error: ' + e.toString()); } catch (_) {}
      print('PDF export error: ' + e.toString() + '\n' + st.toString());
    }
  }

  pw.PageTheme _theme({bool landscape = false}) => pw.PageTheme(
    pageFormat: landscape ? PdfPageFormat.a4.landscape : PdfPageFormat.a4,
    margin: const pw.EdgeInsets.all(24),
  );

  List<pw.Widget> _detailedBlocks(List<Subitem> items, Map<String, List<Attachment>> attBySub, pw.Font fontBase, pw.Font fontBold) {
    final widgets = <pw.Widget>[];
    for (final s in items) {
      if (s.type == SubitemType.folder) {
        widgets.add(pw.Padding(padding: const pw.EdgeInsets.only(top: 12, bottom: 4), child: pw.Text('Папка: ${s.title}', style: pw.TextStyle(font: fontBold, fontSize: 16))));
        continue;
      }
      widgets.add(pw.Padding(padding: const pw.EdgeInsets.only(top: 12, bottom: 4), child: pw.Text('Подзадача: ${s.title}', style: pw.TextStyle(font: fontBold, fontSize: 14))));
      if (s.note != null && s.note!.trim().isNotEmpty) {
        widgets.add(pw.Padding(padding: const pw.EdgeInsets.only(bottom: 6), child: pw.Text(s.note!, style: pw.TextStyle(font: fontBase))));
      }
      final atts = attBySub[s.id] ?? const <Attachment>[];
      final images = atts.where((a) => a.mimeType.startsWith('image/')).toList();
      final others = atts.where((a) => !a.mimeType.startsWith('image/')).toList();

      if (images.isNotEmpty) {
        widgets.add(pw.Wrap(spacing: 8, runSpacing: 8, children: images.map((a) {
          final img = pw.MemoryImage(a.bytes);
          return pw.Container(width: 170, height: 128, decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey600, width: 0.5)), child: pw.ClipRRect(verticalRadius: 2, horizontalRadius: 2, child: pw.Image(img, fit: pw.BoxFit.cover)));
        }).toList()));
      }
      if (others.isNotEmpty) {
        widgets.add(pw.Padding(padding: const pw.EdgeInsets.only(top: 6), child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          pw.Text('Файлы:', style: pw.TextStyle(font: fontBold)),
          ...others.map((a) => pw.Text('• ${a.filename}', style: pw.TextStyle(font: fontBase))).toList(),
        ])));
      }
      widgets.add(pw.Divider());
    }
    return widgets;
  }
}
