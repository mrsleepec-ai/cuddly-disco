// lib/services/pdf_export.dart
import 'dart:typed_data';
import 'dart:html' as html;

import 'package:intl/intl.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'package:hive/hive.dart';
import 'package:printing/printing.dart' show PdfGoogleFonts;

import '../models/task.dart';
import '../models/subitem.dart';
import '../models/attachment.dart';

enum PdfVariant { compact, detailed, checklist }

class PdfExporter {
  Future<void> exportTask(String taskId, PdfVariant variant, {int days = 28}) async {
    final tasks = Hive.box<Task>('tasks');
    final subs = Hive.box<Subitem>('subitems');
    final atts = Hive.box<Attachment>('attachments');

    final task = tasks.get(taskId);
    if (task == null) return;

    final subitems = subs.values.where((s) => s.taskId == taskId).toList()
      ..sort((a, b) => a.createdAt.compareTo(b.createdAt));

    final baseFont = await PdfGoogleFonts.notoSansRegular();
    final boldFont = await PdfGoogleFonts.notoSansBold();
    final doc = pw.Document();

    if (variant == PdfVariant.checklist) {
      final checked = subitems
          .where((s) => s.type == SubitemType.subtask && (s.checked == true))
          .toList()
        ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
      if (checked.isEmpty) {
        // Пусто — ничего не создаём
        return;
      }

      final foldersById = <String, Subitem>{
        for (final f in subitems.where((x) => x.type == SubitemType.folder)) f.id: f
      };
      final grouped = <String?, List<Subitem>>{};
      for (final s in checked) {
        (grouped[s.parentFolderId] ??= []).add(s);
      }

      doc.addPage(
        pw.MultiPage(
          theme: pw.ThemeData.withFont(base: baseFont, bold: boldFont),
          pageTheme: pw.PageTheme(margin: const pw.EdgeInsets.fromLTRB(24, 24, 24, 24)),
          build: (ctx) {
            final widgets = <pw.Widget>[];
            widgets.add(pw.Header(
              level: 0,
              child: pw.Text('Чеклист: ${task.title}', style: pw.TextStyle(font: boldFont, fontSize: 22)),
            ));
            widgets.add(pw.SizedBox(height: 6));
            widgets.add(pw.Text('Отмеченные подзадачи', style: pw.TextStyle(font: baseFont)));

            final keys = grouped.keys.toList()
              ..sort((a, b) {
                if (a == b) return 0;
                if (a == null) return -1;
                if (b == null) return 1;
                return foldersById[a]!.createdAt.compareTo(foldersById[b]!.createdAt);
              });

            for (final key in keys) {
              final list = grouped[key]!;
              final title = key == null ? '(Без папки)' : foldersById[key]!.title;
              widgets.add(pw.Padding(
                padding: const pw.EdgeInsets.only(top: 8, bottom: 4),
                child: pw.Text(title, style: pw.TextStyle(font: boldFont, fontSize: 14)),
              ));
              for (final s in list) {
                widgets.add(pw.Padding(
                  padding: const pw.EdgeInsets.only(left: 8, bottom: 2),
                  child: pw.Text('• ' + s.title, style: pw.TextStyle(font: baseFont)),
                ));
              }
            }

            return widgets;
          },
        ),
      );

      await _savePdf('${_sanitize(task.title)}-checklist.pdf', await doc.save());

      // Сбросить галки
      for (final s in checked) {
        final obj = subs.get(s.id);
        if (obj != null) {
          obj.checked = false;
          await obj.save();
        }
      }
      return;
    }

    // COMPACT / DETAILED
    final folders = subitems.where((s) => s.type == SubitemType.folder).toList();
    final subsByParent = <String?, List<Subitem>>{};
    for (final s in subitems.where((s) => s.type == SubitemType.subtask)) {
      (subsByParent[s.parentFolderId] ??= []).add(s);
    }

    doc.addPage(
      pw.MultiPage(
        theme: pw.ThemeData.withFont(base: baseFont, bold: boldFont),
        pageTheme: pw.PageTheme(margin: const pw.EdgeInsets.fromLTRB(24, 24, 24, 24)),
        build: (ctx) {
          final widgets = <pw.Widget>[];
          widgets.add(pw.Header(
            level: 0,
            child: pw.Text(task.title, style: pw.TextStyle(font: boldFont, fontSize: 24)),
          ));
          widgets.add(pw.Text(
            'Экспорт: ${DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now())}',
            style: pw.TextStyle(font: baseFont),
          ));
          widgets.add(pw.SizedBox(height: 12));

          // Без папки
          final rootList = subsByParent[null] ?? const <Subitem>[];
          widgets.add(pw.Text('Без папки', style: pw.TextStyle(font: boldFont, fontSize: 14)));
          if (rootList.isEmpty) {
            widgets.add(pw.Text('(нет подзадач)', style: pw.TextStyle(font: baseFont)));
          } else {
            for (final s in rootList) {
              widgets.add(pw.Text('• ' + s.title, style: pw.TextStyle(font: baseFont)));
              // В детальном PDF показываем вложения (фото и файлы)
              if (variant == PdfVariant.detailed) {
                final attachments = atts.values.where((a) => a.subitemId == s.id).toList()
                  ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
                if (attachments.isNotEmpty) {
                  final images = attachments.where((a) => a.mimeType.startsWith('image/')).toList();
                  final others = attachments.where((a) => !a.mimeType.startsWith('image/')).toList();

                  if (images.isNotEmpty) {
                    widgets.add(pw.Padding(
                      padding: const pw.EdgeInsets.only(left: 12, top: 6, bottom: 6),
                      child: pw.Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: images.map((a) => pw.Container(
                          width: 96,
                          height: 96,
                          decoration: pw.BoxDecoration(
                            border: pw.Border.all(color: PdfColors.grey300, width: 0.5),
                            borderRadius: pw.BorderRadius.circular(4),
                          ),                          child: pw.Image(pw.MemoryImage(a.bytes), fit: pw.BoxFit.cover),
                        )).map<pw.Widget>((e) => e).toList(),
                      ),
                    ));
                  }

                  if (others.isNotEmpty) {
                    widgets.add(pw.Padding(
                      padding: const pw.EdgeInsets.only(left: 12, top: 2, bottom: 6),
                      child: pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: others.map((a) => pw.Text('— ' + a.filename, style: pw.TextStyle(font: baseFont))).map<pw.Widget>((e) => e).toList(),
                      ),
                    ));
                  }
                }
              }

            }
          }
          widgets.add(pw.SizedBox(height: 8));

          // Папки
          for (final f in folders) {
            widgets.add(pw.Text(f.title, style: pw.TextStyle(font: boldFont, fontSize: 14)));
            final list = subsByParent[f.id] ?? const <Subitem>[];
            if (list.isEmpty) {
              widgets.add(pw.Text('(пусто)', style: pw.TextStyle(font: baseFont)));
            } else {
              for (final s in list) {
                widgets.add(pw.Text('• ' + s.title, style: pw.TextStyle(font: baseFont)));
              // В детальном PDF показываем вложения (фото и файлы)
              if (variant == PdfVariant.detailed) {
                final attachments = atts.values.where((a) => a.subitemId == s.id).toList()
                  ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
                if (attachments.isNotEmpty) {
                  final images = attachments.where((a) => a.mimeType.startsWith('image/')).toList();
                  final others = attachments.where((a) => !a.mimeType.startsWith('image/')).toList();

                  if (images.isNotEmpty) {
                    widgets.add(pw.Padding(
                      padding: const pw.EdgeInsets.only(left: 12, top: 6, bottom: 6),
                      child: pw.Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: images.map((a) => pw.Container(
                          width: 96,
                          height: 96,
                          decoration: pw.BoxDecoration(
                            border: pw.Border.all(color: PdfColors.grey300, width: 0.5),
                            borderRadius: pw.BorderRadius.circular(4),
                          ),                          child: pw.Image(pw.MemoryImage(a.bytes), fit: pw.BoxFit.cover),
                        )).map<pw.Widget>((e) => e).toList(),
                      ),
                    ));
                  }

                  if (others.isNotEmpty) {
                    widgets.add(pw.Padding(
                      padding: const pw.EdgeInsets.only(left: 12, top: 2, bottom: 6),
                      child: pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: others.map((a) => pw.Text('— ' + a.filename, style: pw.TextStyle(font: baseFont))).map<pw.Widget>((e) => e).toList(),
                      ),
                    ));
                  }
                }
              }

                
if (variant == PdfVariant.detailed) {
  final attachments = atts.values.where((a) => a.subitemId == s.id).toList()
    ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
  if (attachments.isNotEmpty) {
    final images = attachments.where((a) => a.mimeType.startsWith('image/')).toList();
    final others = attachments.where((a) => !a.mimeType.startsWith('image/')).toList();

    if (images.isNotEmpty) {
      widgets.add(pw.Padding(
        padding: const pw.EdgeInsets.only(left: 12, top: 6, bottom: 6),
        child: pw.Wrap(
          spacing: 6,
          runSpacing: 6,
          children: images.map((a) => pw.Container(
            width: 96,
            height: 96,
            decoration: pw.BoxDecoration(
              border: pw.Border.all(color: PdfColors.grey300, width: 0.5),
              borderRadius: pw.BorderRadius.circular(4),
            ),            child: pw.Image(pw.MemoryImage(a.bytes), fit: pw.BoxFit.cover),
          )).map<pw.Widget>((e) => e).toList(),
        ),
      ));
    }

    if (others.isNotEmpty) {
      widgets.add(pw.Padding(
        padding: const pw.EdgeInsets.only(left: 12, top: 2, bottom: 6),
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: others.map((a) => pw.Text('— ' + a.filename, style: pw.TextStyle(font: baseFont))).map<pw.Widget>((e) => e).toList(),
        ),
      ));
    }
  }
}
}
              }
            }
            widgets.add(pw.SizedBox(height: 8));
          }

          return widgets;
        },
      ),
    );

    await _savePdf('${_sanitize(task.title)}-${variant == PdfVariant.detailed ? 'detailed' : 'compact'}.pdf', await doc.save());
  }

  Future<void> _savePdf(String filename, Uint8List bytes) async {
    final url = html.Url.createObjectUrlFromBlob(html.Blob([bytes], 'application/pdf'));
    try {
      html.AnchorElement(href: url)..download = filename..click();
    } finally {
      // освободим URL после старта скачивания
      Future<void>.delayed(const Duration(seconds: 1)).then((_) {
        try { html.Url.revokeObjectUrl(url); } catch (_) {}
      });
    }
  }

  String _sanitize(String s) {
    return s.replaceAll(RegExp(r'[^a-zA-Zа-яА-Я0-9 _\-]'), '_');
  }
}
