// lib/services/pdf_export.dart (reconstructed)
import 'dart:typed_data';
import 'dart:html' as html;

import 'package:intl/intl.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'package:hive/hive.dart';
import 'package:printing/printing.dart' show PdfGoogleFonts;

import '../models/task.dart';
import '../models/subitem.dart';
import '../models/attachment.dart';

enum PdfVariant { compact, detailed, checklist }

class PdfExporter {
  Future<void> exportTask(String taskId, PdfVariant variant, {int days = 28}) async {
    // Load data
    final tasks = Hive.box<Task>('tasks');
    final subs = Hive.box<Subitem>('subitems');
    final atts = Hive.box<Attachment>('attachments');

    final task = tasks.get(taskId);
    if (task == null) return;

    final subitems = subs.values.where((s) => s.taskId == taskId).toList()
      ..sort((a, b) => a.createdAt.compareTo(b.createdAt));

    // CHECKLIST variant: only checked subtasks, grouped by folder, then reset checks
    if (variant == PdfVariant.checklist) {
      final checked = subitems.where((s) => s.type == SubitemType.subtask && (s.checked == true)).toList()
        ..sort((a,b)=> a.createdAt.compareTo(b.createdAt));
      if (checked.isEmpty) return;

      final foldersById = <String, Subitem>{ for (final f in subitems.where((x)=> x.type == SubitemType.folder)) f.id: f };
      final grouped = <String?, List<Subitem>>{};
      for (final s in checked) {
        (grouped[s.parentFolderId] ??= []).add(s);
      }

      final baseFont = await PdfGoogleFonts.notoSansRegular();
      final boldFont = await PdfGoogleFonts.notoSansBold();
      final doc = pw.Document();

      doc.addPage(
        pw.MultiPage(
          theme: pw.ThemeData.withFont(base: baseFont, bold: boldFont),
          pageTheme: pw.PageTheme(
            margin: const pw.EdgeInsets.fromLTRB(24, 24, 24, 24),
          ),
          build: (_) {
            final widgets = <pw.Widget>[];
            widgets.add(pw.Header(level: 0, child: pw.Text('Чеклист: ${task.title}', style: pw.TextStyle(fontSize: 22, font: boldFont))));
            widgets.add(pw.SizedBox(height: 8));

            final keys = grouped.keys.toList()
              ..sort((a,b){
                if (a == b) return 0;
                if (a == null) return -1;
                if (b == null) return 1;
                final fa = foldersById[a]!;
                final fb = foldersById[b]!;
                return fa.createdAt.compareTo(fb.createdAt);
              });

            for (final key in keys) {
              final list = grouped[key]!;
              final title = key == null ? '(Без папки)' : foldersById[key]!.title;
              widgets.add(pw.Padding(
                padding: const pw.EdgeInsets.only(top: 6, bottom: 4),
                child: pw.Text(title, style: pw.TextStyle(font: boldFont, fontSize: 14)),
              ));
              for (final s in list) {
                widgets.add(pw.Padding(
                  padding: const pw.EdgeInsets.only(left: 8, bottom: 2),
                  child: pw.Text('• ' + s.title),
                ));
              }
            }

            return widgets;
          },
        ),
      );

      await _savePdf('${_sanitize(task.title)}-checklist.pdf', await doc.save());

      // Reset checks
      for (final s in checked) {
        final obj = subs.get(s.id);
        if (obj != null) {
          obj.checked = false;
          await obj.save();
        }
      }
      return;
    }

    // COMPACT / DETAILED: simple grouped listing; in detailed we add attachments list
    final baseFont = await PdfGoogleFonts.notoSansRegular();
    final boldFont = await PdfGoogleFonts.notoSansBold();
    final doc = pw.Document();

    final folders = subitems.where((s) => s.type == SubitemType.folder).toList();
    final subsByParent = <String?, List<Subitem>>{};
    for (final s in subitems.where((s)=> s.type == SubitemType.subtask)) {
      (subsByParent[s.parentFolderId] ??= []).add(s);
    }

    doc.addPage(
      pw.MultiPage(
        theme: pw.ThemeData.withFont(base: baseFont, bold: boldFont),
        pageTheme: pw.PageTheme(margin: const pw.EdgeInsets.fromLTRB(24,24,24,24)),
        build: (_) {
          final widgets = <pw.Widget>[];
          widgets.add(pw.Header(level: 0, child: pw.Text(task.title, style: pw.TextStyle(font: boldFont, fontSize: 24))));
          widgets.add(pw.Text('Экспорт: ${DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now())}'));
          widgets.add(pw.SizedBox(height: 12));

          // root
          final rootList = subsByParent[null] ?? const <Subitem>[];
          widgets.add(pw.Text('Без папки', style: pw.TextStyle(font: boldFont, fontSize: 14)));
          if (rootList.isEmpty) {
            widgets.add(pw.Text('(нет подзадач)'));
          } else {
            for (final s in rootList) {
              widgets.add(pw.Text('• ' + s.title));
            }
          }
          widgets.add(pw.SizedBox(height: 8));

          // folders
          for (final f in folders) {
            widgets.add(pw.Text(f.title, style: pw.TextStyle(font: boldFont, fontSize: 14)));
            final list = subsByParent[f.id] ?? const <Subitem>[];
            if (list.isEmpty) {
              widgets.add(pw.Text('(пусто)'));
            } else {
              for (final s in list) {
                widgets.add(pw.Text('• ' + s.title));
                if (variant == PdfVariant.detailed) {
                  final attachments = atts.values.where((a)=> a.subitemId == s.id).toList()
                    ..sort((a,b)=> a.createdAt.compareTo(b.createdAt));
                  if (attachments.isNotEmpty) {
                    widgets.add(pw.Padding(
                      padding: const pw.EdgeInsets.only(left: 12, top: 2, bottom: 6),
                      child: pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: attachments.map((a)=> pw.Text('— ' + a.filename)).toList(),
                      ),
                    ));
                  }
                }
              }
            }
            widgets.add(pw.SizedBox(height: 8));
          }

          return widgets;
        },
      ),
    );

    await _savePdf('${_sanitize(task.title)}-${variant == PdfVariant.detailed ? 'detailed' : 'compact'}.pdf', await doc.save());
  }

  Future<void> _savePdf(String filename, Uint8List bytes) async {
    final url = html.Url.createObjectUrlFromBlob(html.Blob([bytes], 'application/pdf'));
    try {
      html.AnchorElement(href: url)
        ..download = filename
        ..click();
    } finally {
      // Revoke shortly after to let the browser start the download
      Future<void>.delayed(const Duration(seconds: 1)).then((_) {
        try { html.Url.revokeObjectUrl(url); } catch (_) {}
      });
    }
  }

  String _sanitize(String s) {
    return s.replaceAll(RegExp(r'[^a-zA-Zа-яА-Я0-9 _\-]'), '_');
  }
}
