import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Универсальный ввод текста через нижний лист.
/// Делает поле полноширинным снизу, чтобы клавиатура его не перекрывала на iOS Safari/Flutter Web.
Future<String?> promptText(
  BuildContext context, {
  required String title,
  String? initial,
  String hintText = 'Введите текст…',
}) async {
  final controller = TextEditingController(text: initial ?? '');
  final focusNode = FocusNode();

  final result = await showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) {
      return _PromptSheet(
        title: title,
        controller: controller,
        focusNode: focusNode,
        hintText: hintText,
      );
    },
  );

  focusNode.dispose();
  controller.dispose();
  return result;
}

class _PromptSheet extends StatefulWidget {
  const _PromptSheet({
    required this.title,
    required this.controller,
    required this.focusNode,
    required this.hintText,
  });

  final String title;
  final TextEditingController controller;
  final FocusNode focusNode;
  final String hintText;

  @override
  State<_PromptSheet> createState() => _PromptSheetState();
}

class _PromptSheetState extends State<_PromptSheet> {
  @override
  void initState() {
    super.initState();
    _ensureKeyboard();
  }

  Future<void> _ensureKeyboard() async {
    // Даем анимациям/тапу на FAB завершиться
    await Future<void>.delayed(const Duration(milliseconds: 120));
    if (!mounted) return;
    widget.focusNode.requestFocus();
    try { await SystemChannels.textInput.invokeMethod('TextInput.show'); } catch (_) {}
    // Повторяем пару раз — на iOS/Flutter Web первая команда иногда игнорируется
    for (var i = 0; i < 2; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 100));
      if (!mounted) return;
      if (!widget.focusNode.hasFocus) {
        FocusScope.of(context).requestFocus(widget.focusNode);
      }
      try { await SystemChannels.textInput.invokeMethod('TextInput.show'); } catch (_) {}
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;
    return AnimatedPadding(
      duration: const Duration(milliseconds: 150),
      curve: Curves.easeOut,
      padding: EdgeInsets.only(bottom: bottomInset),
      child: Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
          boxShadow: [BoxShadow(blurRadius: 12, color: Colors.black26)],
        ),
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(widget.title, style: Theme.of(context).textTheme.titleMedium),
                  ),
                  IconButton(
                    tooltip: 'Закрыть',
                    onPressed: () => Navigator.of(context).pop(null),
                    icon: const Icon(Icons.close),
                  )
                ],
              ),
              const SizedBox(height: 8),
              TextField(
                controller: widget.controller,
                focusNode: widget.focusNode,
                autofocus: true,
                textInputAction: TextInputAction.done,
                onTap: () async {
                  try { await SystemChannels.textInput.invokeMethod('TextInput.show'); } catch (_) {}
                },
                onSubmitted: (v) {
                  final t = v.trim();
                  Navigator.of(context).pop(t.isEmpty ? null : t);
                },
                decoration: InputDecoration(
                  hintText: widget.hintText,
                  filled: true,
                  fillColor: Colors.grey.shade100,
                  border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                ),
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: () {
                  final t = widget.controller.text.trim();
                  Navigator.of(context).pop(t.isEmpty ? null : t);
                },
                child: const Text('Готово'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Универсальное подтверждение действия.
Future<bool> confirm(
  BuildContext context, {
  String? title,
  required String text,
  String confirmText = 'ОК',
  String cancelText = 'Отмена',
}) async {
  final res = await showDialog<bool>(
    context: context,
    barrierDismissible: true,
    builder: (ctx) {
      return AlertDialog(
        title: title != null ? Text(title) : null,
        content: Text(text),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(cancelText),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(confirmText),
          ),
        ],
      );
    },
  );
  return res ?? false;
}
