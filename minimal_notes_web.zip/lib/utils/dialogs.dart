import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Универсальный диалог ввода текста с автофокусом и мягким подъемом под клавиатуру.
Future<String?> promptText(
  BuildContext context, {
  required String title,
  String? initial,
  String hintText = 'Введите текст…',
}) async {
  final controller = TextEditingController(text: initial ?? '');
  final focusNode = FocusNode();

  final result = await showDialog<String>(
    context: context,
    barrierDismissible: true,
    useSafeArea: true,
    builder: (ctx) {
      return Dialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: _PromptBody(
          title: title,
          controller: controller,
          focusNode: focusNode,
          hintText: hintText,
        ),
      );
    },
  );

  focusNode.dispose();
  controller.dispose();
  return result;
}

class _PromptBody extends StatefulWidget {
  const _PromptBody({
    required this.title,
    required this.controller,
    required this.focusNode,
    required this.hintText,
  });

  final String title;
  final TextEditingController controller;
  final FocusNode focusNode;
  final String hintText;

  @override
  State<_PromptBody> createState() => _PromptBodyState();
}

class _PromptBodyState extends State<_PromptBody> {
  @override
  void initState() {
    super.initState();
    _ensureKeyboard();
  }

  Future<void> _ensureKeyboard() async {
    // Даем закрыться popup-меню/анимациям перед фокусом
    await Future<void>.delayed(const Duration(milliseconds: 180));
    if (!mounted) return;
    widget.focusNode.requestFocus();
    try { await SystemChannels.textInput.invokeMethod('TextInput.show'); } catch (_) {}

    // Повторные попытки — на некоторых девайсах первая не срабатывает после старта приложения
    for (var i = 0; i < 3; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 120));
      if (!mounted) return;
      if (widget.focusNode.hasFocus) {
        // Пинг клавиатуры всё равно полезен для Android
        try { await SystemChannels.textInput.invokeMethod('TextInput.show'); } catch (_) {}
        break;
      } else {
        FocusScope.of(context).requestFocus(widget.focusNode);
        try { await SystemChannels.textInput.invokeMethod('TextInput.show'); } catch (_) {}
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return AnimatedPadding(
      duration: const Duration(milliseconds: 150),
      curve: Curves.easeOut,
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: bottom + 16),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(widget.title, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            TextField(
              controller: widget.controller,
              focusNode: widget.focusNode,
              autofocus: true, // оставляем, но дублируем ручным фокусом
              textInputAction: TextInputAction.done,
              onTap: () async {
                // Если пользователь ткнул — гарантированно покажем клавиатуру
                try { await SystemChannels.textInput.invokeMethod('TextInput.show'); } catch (_) {}
              },
              onSubmitted: (v) {
                final t = v.trim();
                Navigator.of(context).pop(t.isEmpty ? null : t);
              },
              decoration: InputDecoration(hintText: widget.hintText),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(null),
                  child: const Text('Отмена'),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: () {
                    final t = widget.controller.text.trim();
                    Navigator.of(context).pop(t.isEmpty ? null : t);
                  },
                  child: const Text('Готово'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Универсальное подтверждение действия.
Future<bool> confirm(
  BuildContext context, {
  String? title,
  required String text,
  String confirmText = 'ОК',
  String cancelText = 'Отмена',
}) async {
  final res = await showDialog<bool>(
    context: context,
    barrierDismissible: true,
    builder: (ctx) {
      return AlertDialog(
        title: title != null ? Text(title) : null,
        content: Text(text),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(cancelText),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(confirmText),
          ),
        ],
      );
    },
  );
  return res ?? false;
}
