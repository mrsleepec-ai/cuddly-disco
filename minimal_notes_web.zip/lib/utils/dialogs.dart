import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Универсальный диалог ввода текста с автофокусом и мягким подъемом под клавиатуру.
Future<String?> promptText(
  BuildContext context, {
  required String title,
  String? initial,
  String hintText = 'Введите текст…',
}) async {
  final controller = TextEditingController(text: initial ?? '');
  final focusNode = FocusNode();

  final result = await showDialog<String>(
    context: context,
    barrierDismissible: true,
    useSafeArea: true,
    builder: (ctx) {
      return Dialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: StatefulBuilder(
          builder: (ctx, setState) {
            WidgetsBinding.instance.addPostFrameCallback((_) async {
              if (!focusNode.hasFocus) {
                focusNode.requestFocus();
              }
              try {
                await SystemChannels.textInput.invokeMethod('TextInput.show');
              } catch (_) {}
            });

            final bottom = MediaQuery.of(ctx).viewInsets.bottom;
            return AnimatedPadding(
              duration: const Duration(milliseconds: 150),
              curve: Curves.easeOut,
              padding: EdgeInsets.only(
                left: 16,
                right: 16,
                top: 16,
                bottom: bottom + 16,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(title, style: Theme.of(ctx).textTheme.titleMedium),
                    const SizedBox(height: 12),
                    TextField(
                      controller: controller,
                      focusNode: focusNode,
                      autofocus: true,
                      textInputAction: TextInputAction.done,
                      onSubmitted: (v) {
                        final t = v.trim();
                        Navigator.of(ctx).pop(t.isEmpty ? null : t);
                      },
                      decoration: InputDecoration(
                        hintText: hintText,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton(
                          onPressed: () => Navigator.of(ctx).pop(null),
                          child: const Text('Отмена'),
                        ),
                        const SizedBox(width: 8),
                        FilledButton(
                          onPressed: () {
                            final t = controller.text.trim();
                            Navigator.of(ctx).pop(t.isEmpty ? null : t);
                          },
                          child: const Text('Готово'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      );
    },
  );

  focusNode.dispose();
  controller.dispose();
  return result;
}
