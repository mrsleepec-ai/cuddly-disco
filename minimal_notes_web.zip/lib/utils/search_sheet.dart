import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

Future<String?> showSearchSheet(
  BuildContext context, {
    String initial = '',
    String hintText = 'Поиск…',
  }
) async {
  final ctl = TextEditingController(text: initial);
  final node = FocusNode();

  final result = await showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) {
      return SafeArea(
        top: false,
        child: _SearchBody(
          controller: ctl,
          node: node,
          hintText: hintText,
        ),
      );
    },
  );

  node.dispose();
  ctl.dispose();
  return result;
}

class _SearchBody extends StatefulWidget {
  const _SearchBody({required this.controller, required this.node, required this.hintText});
  final TextEditingController controller;
  final FocusNode node;
  final String hintText;

  @override
  State<_SearchBody> createState() => _SearchBodyState();
}

class _SearchBodyState extends State<_SearchBody> {
  @override
  void initState() {
    super.initState();
    _ensureKeyboard();
  }

  Future<void> _ensureKeyboard() async {
    await Future<void>.delayed(const Duration(milliseconds: 180));
    if (!mounted) return;
    widget.node.requestFocus();
    try { await SystemChannels.textInput.invokeMethod('TextInput.show'); } catch (_) {}
    for (var i = 0; i < 3; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 120));
      if (!mounted) return;
      if (!widget.node.hasFocus) {
        FocusScope.of(context).requestFocus(widget.node);
      }
      try { await SystemChannels.textInput.invokeMethod('TextInput.show'); } catch (_) {}
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedPadding(
      duration: const Duration(milliseconds: 150),
      curve: Curves.easeOut,
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: TextField(
        controller: widget.controller,
        focusNode: widget.node,
        autofocus: true,
        textInputAction: TextInputAction.search,
        onTap: () async {
          try { await SystemChannels.textInput.invokeMethod('TextInput.show'); } catch (_) {}
        },
        onSubmitted: (v) => Navigator.of(context).pop(v.trim().isEmpty ? null : v.trim()),
        decoration: InputDecoration(hintText: widget.hintText),
      ),
    );
  }
}
