import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

Future<String?> showSearchSheet(
  BuildContext context, {
    String initial = '',
    String hintText = 'Поиск…',
  }
) async {
  final ctl = TextEditingController(text: initial);
  final node = FocusNode();

  final result = await showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) {
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        if (!node.hasFocus) node.requestFocus();
        try { await SystemChannels.textInput.invokeMethod('TextInput.show'); } catch (_) {}
      });

      return SafeArea(
        top: false,
        child: AnimatedPadding(
          duration: const Duration(milliseconds: 150),
          curve: Curves.easeOut,
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 16,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
          ),
          child: TextField(
            controller: ctl,
            focusNode: node,
            autofocus: true,
            textInputAction: TextInputAction.search,
            onSubmitted: (v) => Navigator.of(ctx).pop(v.trim().isEmpty ? null : v.trim()),
            decoration: InputDecoration(hintText: hintText),
          ),
        ),
      );
    },
  );

  node.dispose();
  ctl.dispose();
  return result;
}
