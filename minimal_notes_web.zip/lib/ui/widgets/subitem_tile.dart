import 'package:flutter/material.dart';
import 'package:minimal_notes_web/utils/dialogs.dart';
import '../../models/subitem.dart';

class SubitemTile extends StatelessWidget {
  final Subitem subitem;
  final VoidCallback onOpen;
  final VoidCallback onRename;
  final VoidCallback onDelete;

  const SubitemTile({
    super.key,
    required this.subitem,
    required this.onOpen,
    required this.onRename,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final isFolder = subitem.type.name == 'folder';
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: ListTile(
        leading: Icon(isFolder ? Icons.folder : Icons.check_box_outline_blank),
        title: Text(subitem.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: isFolder ? const Text('Папка') : null,
        onTap: onOpen,
        trailing: PopupMenuButton<String>(
          onSelected: (v) {
            switch (v) {
              case 'rename':
                onRename();
                break;
              case 'delete':
                onDelete();
                break;
            }
          },
          itemBuilder: (ctx) => const [
            PopupMenuItem(value: 'rename', child: Text('Переименовать')),
            PopupMenuItem(value: 'delete', child: Text('Удалить')),
          ],
        ),
      ),
    );
  }
}
