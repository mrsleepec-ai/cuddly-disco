import 'package:flutter/material.dart';
import '../../models/subitem.dart';

class SubitemTile extends StatelessWidget {
  final Subitem subitem;
  final VoidCallback onOpen;
  final VoidCallback onRename;
  final VoidCallback onDelete;
  final ValueChanged<bool>? onToggleChecked;
  final ValueChanged<Subitem>? onMove;

  const SubitemTile({
    super.key,
    required this.subitem,
    required this.onOpen,
    required this.onRename,
    required this.onDelete,
    this.onToggleChecked,
    this.onMove,
  });

  @override
  Widget build(BuildContext context) {
    final isFolder = subitem.type == SubitemType.folder;

    Widget? leading;
    if (isFolder) {
      leading = const Icon(Icons.folder);
    } else {
      leading = Checkbox(
        value: subitem.checked == true,
        onChanged: (v) {
          if (onToggleChecked != null && v != null) onToggleChecked!(v);
        },
      );
    }

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: ListTile(
        leading: leading,
        title: Text(subitem.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: isFolder ? const Text('Папка') : null,
        onTap: onOpen,
        trailing: PopupMenuButton<String>(
          onSelected: (v) async {
            switch (v) {
              case 'rename':
                onRename();
                break;
              case 'move':
                if (!isFolder && onMove != null) onMove!(subitem);
                break;
              case 'delete':
                onDelete();
                break;
            }
          },
          itemBuilder: (ctx) => <PopupMenuEntry<String>>[
            const PopupMenuItem(value: 'rename', child: Text('Переименовать')),
            if (!isFolder)
              const PopupMenuItem(value: 'move', child: Text('Переместить в папку…')),
            const PopupMenuItem(value: 'delete', child: Text('Удалить')),
          ],
        ),
      ),
    );
  }
}
