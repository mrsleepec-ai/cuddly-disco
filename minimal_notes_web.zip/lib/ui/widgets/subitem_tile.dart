import 'package:flutter/material.dart';
import 'package:minimal_notes_web/utils/dialogs.dart';
import '../../models/subitem.dart';

class SubitemTile extends StatelessWidget {
  final Subitem subitem;
  final VoidCallback onOpen;
  final VoidCallback onRename;
  final VoidCallback onDelete;
  final ValueChanged<bool>? onToggleChecked;
  final ValueChanged<Subitem>? onMove;

  const SubitemTile({
    super.key,
    required this.subitem,
    required this.onOpen,
    required this.onRename,
    required this.onDelete,
    this.onToggleChecked,
    this.onMove,
  });

  @override
  Widget build(BuildContext context) {
    final isFolder = subitem.type == SubitemType.folder;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: ListTile(
        leading: Icon(isFolder ? Icons.folder : Icons.check_box_outlined),
        title: Text(subitem.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: isFolder ? const Text('Папка') : null,
        onTap: onOpen,
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (subitem.type == SubitemType.subtask)
              Checkbox(
                value: subitem.checked == true,
                onChanged: (v) {
                  if (onToggleChecked != null && v != null) onToggleChecked!(v);
                },
              ),
            PopupMenuButton<String>(
              onSelected: (v) async {
                switch (v) {
                  case 'rename':
                    onRename();
                    break;
                  case 'move':
                    if (onMove != null) onMove!(subitem);
                    break;
                  case 'delete':
                    onDelete();
                    break;
                }
              },
              itemBuilder: (ctx) => [
                const PopupMenuItem(value: 'rename', child: Text('Переименовать')),
                if (subitem.type == SubitemType.subtask)
                  const PopupMenuItem(value: 'move', child: Text('Переместить в папку…')),
                const PopupMenuItem(value: 'delete', child: Text('Удалить')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
