import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models/subitem.dart';
import '../../services/repository.dart';
import 'package:minimal_notes_web/utils/dialogs.dart';
import '../widgets/subitem_tile.dart';
import 'subitem_detail_page.dart';
import 'home_page.dart';

class TaskDetailPage extends ConsumerStatefulWidget {
  final String taskId;
  final String taskTitle;
  final String? parentFolderId;

  const TaskDetailPage({super.key, required this.taskId, required this.taskTitle, this.parentFolderId});

  @override
  ConsumerState<TaskDetailPage> createState() => _TaskDetailPageState();
}

class _TaskDetailPageState extends ConsumerState<TaskDetailPage> {
  

Future<void> _pickFolderAndMove(Subitem s) async {
  // Получаем все папки для данной задачи
  final folders = await ref.read(repoProvider).listFolders(widget.taskId);
  final selected = await showModalBottomSheet<String?>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) {
      return SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Padding(
              padding: EdgeInsets.all(16.0),
              child: Text('Переместить в папку', style: TextStyle(fontWeight: FontWeight.w600)),
            ),
            ListTile(
              title: const Text('Без папки (в корень)'),
              onTap: () => Navigator.of(ctx).pop(null),
            ),
            const Divider(height: 1),
            ...folders.map((f) => ListTile(
                  title: Text(f.title),
                  trailing: s.parentFolderId == f.id ? const Icon(Icons.check) : null,
                  onTap: () => Navigator.of(ctx).pop(f.id),
                )),
            const SizedBox(height: 8),
          ],
        ),
      );
    },
  );
  if (selected is String?){
    await ref.read(repoProvider).moveSubitemToFolder(subitemId: s.id, targetFolderId: selected);
    if (mounted) setState(() {});
  }
}
@override
  Widget build(BuildContext context) {
    final repo = ref.watch(repoProvider);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.taskTitle),
      ),
      body: FutureBuilder<List<Subitem>>(
        future: repo.listSubitems(taskId: widget.taskId, parentFolderId: widget.parentFolderId),
        builder: (context, snapshot) {
          final items = snapshot.data ?? const <Subitem>[];
          return Column(
            children: [
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  FilledButton.tonal(
                    onPressed: () async {
                      final v = await promptText(context, title: 'Название папки');
                      if (v != null && v.isNotEmpty) {
                        await ref.read(repoProvider).createFolder(widget.taskId, parentFolderId: widget.parentFolderId, title: v);
                        setState(() {});
                      }
                    },
                    child: const Text('Создать папку'),
                  ),
                  FilledButton(
                    onPressed: () async {
                      final v = await promptText(context, title: 'Название подзадачи');
                      if (v != null && v.isNotEmpty) {
                        await ref.read(repoProvider).createSubtask(widget.taskId, parentFolderId: widget.parentFolderId, title: v);
                        setState(() {});
                      }
                    },
                    child: const Text('Создать подзадачу'),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: items.isEmpty
                    ? const Center(child: Text('Нет элементов'))
                    : ListView.builder(
                        itemCount: items.length,
                        itemBuilder: (ctx, i) {
                          final s = items[i];
                          return SubitemTile(onMove: (s)=> _pickFolderAndMove(s), onToggleChecked: (v) async { await ref.read(repoProvider).toggleSubitemChecked(s.id, v); setState(() {}); }, 
                            subitem: s,
                            onOpen: () {
                              if (s.type == SubitemType.folder) {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => TaskDetailPage(
                                      taskId: widget.taskId,
                                      taskTitle: s.title,
                                      parentFolderId: s.id,
                                    ),
                                  ),
                                );
                              } else {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => SubitemDetailPage(subitemId: s.id, title: s.title)),
                                );
                              }
                            },
                            onRename: () async {
                              final v = await promptText(context, title: 'Переименовать', initial: s.title);
                              if (v != null && v.isNotEmpty) {
                                await ref.read(repoProvider).renameSubitem(s.id, v);
                                setState(() {});
                              }
                            },
                            onDelete: () async {
                              final ok = await confirm(context, text: 'Удалить "${s.title}"?');
                              if (ok) {
                                await ref.read(repoProvider).deleteSubitem(s.id);
                                setState(() {});
                              }
                            },
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}
