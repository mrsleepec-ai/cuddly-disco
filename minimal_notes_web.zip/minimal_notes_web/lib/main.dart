import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'models/task.dart';
import 'models/subitem.dart';
import 'models/attachment.dart';
import 'ui/screens/home_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  Hive.registerAdapter(TaskAdapter());
  Hive.registerAdapter(SubitemTypeAdapter());
  Hive.registerAdapter(SubitemAdapter());
  Hive.registerAdapter(AttachmentAdapter());
  await Hive.openBox<Task>('tasks');
  await Hive.openBox<Subitem>('subitems');
  await Hive.openBox<Attachment>('attachments');
  runApp(const ProviderScope(child: MinimalNotesApp()));
}

class MinimalNotesApp extends StatelessWidget {
  const MinimalNotesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Minimal Notes Web',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blueGrey,
        scaffoldBackgroundColor: const Color(0xFFF8F9FB),
        appBarTheme: const AppBarTheme(centerTitle: true, elevation: 0),
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(borderSide: BorderSide.none),
          filled: true,
          fillColor: Colors.white,
          contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        ),
        listTileTheme: const ListTileThemeData(iconColor: Colors.black87),
      ),
      home: const HomePage(),
    );
  }
}
