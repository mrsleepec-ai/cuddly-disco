import 'dart:typed_data';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';

class FileService {
  final ImagePicker _picker = ImagePicker();

  Future<(Uint8List bytes, String filename, String mime)> pickFromCamera() async {
    final x = await _picker.pickImage(source: ImageSource.camera, imageQuality: 90);
    if (x == null) throw Exception('cancelled');
    final bytes = await x.readAsBytes();
    final name = x.name;
    final mime = 'image/jpeg';
    return (bytes, name, mime);
    }

  Future<(Uint8List bytes, String filename, String mime)> pickFromGallery() async {
    final x = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 95);
    if (x == null) throw Exception('cancelled');
    final bytes = await x.readAsBytes();
    final name = x.name;
    final mime = 'image/jpeg';
    return (bytes, name, mime);
  }

  Future<(Uint8List bytes, String filename, String mime)> pickFromFiles() async {
    final res = await FilePicker.platform.pickFiles(allowMultiple: false, withData: true);
    if (res == null || res.files.isEmpty || res.files.single.bytes == null) throw Exception('cancelled');
    final f = res.files.single;
    final bytes = f.bytes!;
    final name = f.name;
    final mime = f.mimeType ?? 'application/octet-stream';
    return (bytes, name, mime);
  }
}
