import 'dart:typed_data';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';

class FileService {
  final ImagePicker _picker = ImagePicker();

  Future<(Uint8List bytes, String filename, String mime)> pickFromCamera() async {
    final x = await _picker.pickImage(source: ImageSource.camera, imageQuality: 90);
    if (x == null) throw Exception('cancelled');
    final bytes = await x.readAsBytes();
    final name = x.name;
    final mime = 'image/jpeg';
    return (bytes, name, mime);
  }

  Future<(Uint8List bytes, String filename, String mime)> pickFromGallery() async {
    final x = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 95);
    if (x == null) throw Exception('cancelled');
    final bytes = await x.readAsBytes();
    final name = x.name;
    final mime = _guessMime(name);
    return (bytes, name, mime);
  }

  Future<(Uint8List bytes, String filename, String mime)> pickFromFiles() async {
    final res = await FilePicker.platform.pickFiles(allowMultiple: false, withData: true);
    if (res == null || res.files.isEmpty || res.files.single.bytes == null) throw Exception('cancelled');
    final f = res.files.single;
    final bytes = f.bytes!;
    final name = f.name;
    final mime = _guessMime(name);
    return (bytes, name, mime);
  }

  String _guessMime(String filename) {
    final lower = filename.toLowerCase();
    if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
    if (lower.endsWith('.png')) return 'image/png';
    if (lower.endsWith('.pdf')) return 'application/pdf';
    if (lower.endsWith('.txt')) return 'text/plain';
    return 'application/octet-stream';
  }
}
