import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import '../models/task.dart';
import '../models/subitem.dart';
import '../models/attachment.dart';

class Repo extends ChangeNotifier {
  final _uuid = const Uuid();
  Box<Task> get _tasks => Hive.box<Task>('tasks');
  Box<Subitem> get _subs => Hive.box<Subitem>('subitems');
  Box<Attachment> get _atts => Hive.box<Attachment>('attachments');

  // ---- Tasks ----
  Future<List<Task>> listTasks() async {
    final items = _tasks.values.toList();
    items.sort((a, b) => a.createdAt.compareTo(b.createdAt)); // old at top
    return items;
  }

  Future<Task> createTask(String title) async {
    final t = Task(id: _uuid.v4(), title: title.trim(), createdAt: DateTime.now());
    await _tasks.put(t.id, t);
    notifyListeners();
    return t;
  }

  Future<void> renameTask(String id, String newTitle) async {
    final t = _tasks.get(id);
    if (t != null) {
      t.title = newTitle.trim();
      await t.save();
      notifyListeners();
    }
  }

  Future<void> setTaskCompleted(String id, bool value) async {
    final t = _tasks.get(id);
    if (t != null) {
      t.completed = value;
      await t.save();
      notifyListeners();
    }
  }

  Future<void> deleteTask(String id) async {
    final subsToDelete = _subs.values.where((s) => s.taskId == id).map((s) => s.id).toList();
    final attsToDelete = _atts.values.where((a) => subsToDelete.contains(a.subitemId)).map((a)=>a.id).toList();
    await _atts.deleteAll(attsToDelete);
    await _subs.deleteAll(subsToDelete);
    await _tasks.delete(id);
    notifyListeners();
  }

  bool isTaskCompletedSync(String taskId) {
    final t = _tasks.get(taskId);
    if (t == null) return false;
    if (t.completed) return true;
    final subs = _subs.values.where((s) => s.taskId == taskId && s.type == SubitemType.subtask).toList();
    if (subs.isEmpty) return false;
    return subs.every((s) => s.completed);
  }

  // ---- Subitems ----
  Future<List<Subitem>> listSubitems({required String taskId, String? parentFolderId}) async {
    final items = _subs.values.where((s) => s.taskId == taskId && s.parentFolderId == parentFolderId).toList();
    items.sort((a, b) => a.createdAt.compareTo(b.createdAt)); // old at top
    return items;
  }

  Future<List<Subitem>> listAllFolders(String taskId) async {
    final items = _subs.values.where((s) => s.taskId == taskId && s.type == SubitemType.folder).toList();
    items.sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
    return items;
  }

  Future<Subitem> createFolder(String taskId, {String? parentFolderId, required String title}) async {
    final s = Subitem(
      id: _uuid.v4(),
      taskId: taskId,
      parentFolderId: parentFolderId,
      type: SubitemType.folder,
      title: title.trim(),
      note: null,
      createdAt: DateTime.now(),
      completed: false,
    );
    await _subs.put(s.id, s);
    notifyListeners();
    return s;
  }

  Future<Subitem> createSubtask(String taskId, {String? parentFolderId, required String title}) async {
    final s = Subitem(
      id: _uuid.v4(),
      taskId: taskId,
      parentFolderId: parentFolderId,
      type: SubitemType.subtask,
      title: title.trim(),
      note: '',
      createdAt: DateTime.now(),
      completed: false,
    );
    await _subs.put(s.id, s);
    notifyListeners();
    return s;
  }

  Future<void> renameSubitem(String id, String newTitle) async {
    final s = _subs.get(id);
    if (s != null) {
      s.title = newTitle.trim();
      await s.save();
      notifyListeners();
    }
  }

  Future<void> setSubitemCompleted(String id, bool value) async {
    final s = _subs.get(id);
    if (s != null) {
      s.completed = value;
      await s.save();
      notifyListeners();
    }
  }

  Future<void> moveSubitem(String id, String? newParentFolderId) async {
    final s = _subs.get(id);
    if (s != null) {
      s.parentFolderId = newParentFolderId;
      await s.save();
      notifyListeners();
    }
  }

  Future<void> deleteSubitem(String id) async {
    final toDelete = _collectNested(id);
    final attIds = _atts.values.where((a) => toDelete.contains(a.subitemId)).map((a)=>a.id).toList();
    await _atts.deleteAll(attIds);
    await _subs.deleteAll(toDelete);
    notifyListeners();
  }

  Set<String> _collectNested(String rootId) {
    final set = <String>{rootId};
    bool changed = true;
    while (changed) {
      changed = false;
      for (final s in _subs.values) {
        if (s.parentFolderId != null && set.contains(s.parentFolderId)) {
          if (set.add(s.id)) changed = true;
        }
      }
    }
    return set;
  }

  Future<Subitem?> readSubitem(String id) async => _subs.get(id);

  Future<void> updateNote(String subitemId, String note) async {
    final s = _subs.get(subitemId);
    if (s != null) {
      s.note = note;
      await s.save();
      notifyListeners();
    }
  }

  Future<List<Attachment>> listAttachments(String subitemId) async {
    final list = _atts.values.where((a) => a.subitemId == subitemId).toList();
    list.sort((a,b)=> a.createdAt.compareTo(b.createdAt)); // old at top
    return list;
  }

  Future<Attachment> addAttachment({
    required String subitemId,
    required String filename,
    required String mimeType,
    required Uint8List bytes,
  }) async {
    final a = Attachment(
      id: _uuid.v4(),
      subitemId: subitemId,
      filename: filename,
      mimeType: mimeType,
      bytes: bytes,
      createdAt: DateTime.now(),
    );
    await _atts.put(a.id, a);
    notifyListeners();
    return a;
  }

  Future<void> removeAttachment(String id) async {
    await _atts.delete(id);
    notifyListeners();
  }
}
