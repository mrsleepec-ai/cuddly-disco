import 'dart:typed_data';
import 'package:intl/intl.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';
import '../models/task.dart';
import '../models/subitem.dart';
import '../models/attachment.dart';
import '../models/subitem.dart';
import 'package:hive/hive.dart';

enum PdfVariant { compact, detailed }

class PdfExporter {
  Future<void> exportTask(String taskId, PdfVariant variant) async {
    final tasks = Hive.box<Task>('tasks');
    final subs = Hive.box<Subitem>('subitems');
    final atts = Hive.box<Attachment>('attachments');

    final task = tasks.get(taskId)!;
    final subitems = subs.values.where((s) => s.taskId == taskId).toList();
    subitems.sort((a,b)=> a.createdAt.compareTo(b.createdAt));

    final attsBySub = <String, List<Attachment>>{};
    for (final s in subitems) {
      attsBySub[s.id] = atts.values.where((a) => a.subitemId == s.id).toList();
    }

    final doc = pw.Document();
    final dateStr = DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now());

    if (variant == PdfVariant.compact) {
      doc.addPage(
        pw.MultiPage(
          pageTheme: _theme(),
          build: (ctx) => [
            pw.Header(level: 0, child: pw.Text(task.title, style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold))),
            pw.Text('Экспорт: $dateStr'),
            pw.SizedBox(height: 12),
            pw.Bullet(text: 'Список элементов'),
            _compactList(subitems),
          ],
        ),
      );
    } else {
      doc.addPage(
        pw.MultiPage(
          pageTheme: _theme(),
          build: (ctx) => [
            pw.Header(level: 0, child: pw.Text(task.title, style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold))),
            pw.Text('Экспорт: $dateStr'),
            pw.SizedBox(height: 16),
            ..._detailedBlocks(subitems, attsBySub),
          ],
        ),
      );
    }

    final bytes = await doc.save();
    final fname = 'task_${task.title.replaceAll(' ', '_')}_${variant.name}.pdf';
    await Printing.sharePdf(bytes: bytes, filename: fname);
  }

  pw.PageTheme _theme() {
    return pw.PageTheme(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(32),
    );
  }

  pw.Widget _compactList(List<Subitem> items) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: items.map((s) {
        final prefix = s.type == SubitemType.folder ? '[Папка]' : '•';
        return pw.Padding(
          padding: const pw.EdgeInsets.symmetric(vertical: 2),
          child: pw.Text('$prefix ${s.title}'),
        );
      }).toList(),
    );
  }

  List<pw.Widget> _detailedBlocks(List<Subitem> items, Map<String, List<Attachment>> attBySub) {
    return items.map((s) {
      final atts = attBySub[s.id] ?? const <Attachment>[];
      return pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(s.type == SubitemType.folder ? 'Папка: ${s.title}' : 'Подзадача: ${s.title}',
              style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
          if (s.note != null && s.note!.trim().isNotEmpty) pw.Padding(
            padding: const pw.EdgeInsets.symmetric(vertical: 4),
            child: pw.Text(s.note!),
          ),
          if (atts.isNotEmpty)
            pw.Padding(
              padding: const pw.EdgeInsets.only(top: 4, bottom: 8),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('Вложения (${atts.length}):'),
                  ...atts.map((a) => pw.Text('• ${a.filename}')).toList(),
                ],
              ),
            ),
          pw.SizedBox(height: 8),
          pw.Divider(),
        ],
      );
    }).toList();
  }
}
