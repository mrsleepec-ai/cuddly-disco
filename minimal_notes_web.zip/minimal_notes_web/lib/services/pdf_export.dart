// lib/services/pdf_export.dart (fixed landscape + hardened fonts)
import 'dart:typed_data';
import 'dart:html' as html;
import 'dart:async';

import 'package:flutter/services.dart' show rootBundle;
import 'package:intl/intl.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'package:hive/hive.dart';

import '../models/task.dart';
import '../models/subitem.dart';
import '../models/attachment.dart';

enum PdfVariant { compact, detailed, checklist }

class PdfExporter {
  Future<void> exportTask(String taskId, PdfVariant variant, {int days = 28}) async {
    String phase = "start";
    try {
      phase = "A:openBoxes";
      final tasks = Hive.box<Task>('tasks');
      final subs = Hive.box<Subitem>('subitems');
      final atts = Hive.box<Attachment>('attachments');

      phase = "B:getTask";
      final task = tasks.get(taskId);
      if (task == null) throw 'Task not found';

      phase = "C:collectSubitems";
      final subitems = subs.values.where((s) => s.taskId == taskId).toList()
        ..sort((a, b) => a.createdAt.compareTo(b.createdAt));

      phase = "D:groupAttachments";
      final attsBySub = <String, List<Attachment>>{};
      for (final s in subitems) {
        attsBySub[s.id] = atts.values.where((a) => a.subitemId == s.id).toList()
          ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
      }

      phase = "E:loadFonts";
      final fonts = await _loadFontsSafe(); // (base, bold)

      phase = "F:newDoc";
      final doc = pw.Document();

      final isChecklist = variant == PdfVariant.compact || variant == PdfVariant.checklist;

      if (isChecklist) {
        phase = "G:dates";
        final start = DateTime(task.createdAt.year, task.createdAt.month, task.createdAt.day);
        if (days <= 0) days = 7;
        int generated = 0;
        while (generated < days) {
          final remain = days - generated;
          final span = remain >= 7 ? 7 : remain;
          final List<DateTime> dates = List.generate(span, (i) => start.add(Duration(days: generated + i)));

          final headers = <String>['Подзадача', ...dates.map((d) => DateFormat('dd.MM').format(d))];
          final onlySubs = subitems.where((s) => s.type == SubitemType.subtask).toList();
          final rows = <List<String>>[];
          if (onlySubs.isEmpty) {
            rows.add(['(нет подзадач)', ...List.filled(dates.length, '')]);
          } else {
            for (final s in onlySubs) {
              rows.add([s.title, ...List.filled(dates.length, '')]);
            }
          }

          phase = "I:addPage";
          doc.addPage(
            pw.MultiPage(
              pageTheme: _theme(landscape: true),
              theme: pw.ThemeData.withFont(base: fonts.$1, bold: fonts.$2),
              build: (ctx) => [
                pw.Header(level: 0, child: pw.Text('Чек-лист: ${task.title}', style: pw.TextStyle(fontSize: 22, font: fonts.$2))),
                pw.Text('Период: ${DateFormat('dd.MM').format(dates.first)} – ${DateFormat('dd.MM').format(dates.last)}', style: pw.TextStyle(font: fonts.$1)),
                pw.SizedBox(height: 10),
                pw.Table.fromTextArray(
                  headers: headers,
                  data: rows,
                  headerStyle: pw.TextStyle(font: fonts.$2),
                  cellStyle: pw.TextStyle(font: fonts.$1, fontSize: 10),
                  headerDecoration: const pw.BoxDecoration(color: PdfColors.grey200),
                  border: pw.TableBorder.all(color: PdfColors.grey600, width: 0.6),
                  cellAlignment: pw.Alignment.centerLeft,
                ),
              ],
            ),
          );
          generated += span;
        }
      } else {
        phase = "J:detailedPage";
        doc.addPage(
          pw.MultiPage(
            pageTheme: _theme(),
            theme: pw.ThemeData.withFont(base: fonts.$1, bold: fonts.$2),
            build: (ctx) => [
              pw.Header(level: 0, child: pw.Text(task.title, style: pw.TextStyle(fontSize: 24, font: fonts.$2))),
              pw.Text('Экспорт: ${DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now())}', style: pw.TextStyle(font: fonts.$1)),
              pw.SizedBox(height: 12),
              ..._detailedBlocks(subitems, attsBySub, fonts.$1, fonts.$2),
            ],
          ),
        );
      }

      phase = "K:save";
      final Uint8List bytes = await doc.save();

      phase = "L:open";
      final url = html.Url.createObjectUrlFromBlob(html.Blob([bytes], 'application/pdf'));
      Future<void>.delayed(const Duration(seconds: 1)).then((_) { try { html.Url.revokeObjectUrl(url); } catch (_) {} });
      html.window.location.href = url;
    } catch (e, st) {
      try { html.window.alert('PDF error [' + phase + ']: ' + e.toString()); } catch (_) {}
      print('PDF export error at ' + phase + ': ' + e.toString() + '\n' + st.toString());
    }
  }

  // -------- Hardened fonts --------
  bool _isValidTtf(Uint8List bytes) {
    if (bytes.length < 1024) return false;
    final b0 = bytes[0], b1 = bytes[1], b2 = bytes[2], b3 = bytes[3];
    // TrueType 0x00010000 or OpenType 'OTTO'
    if (b0 == 0x00 && b1 == 0x01 && b2 == 0x00 && b3 == 0x00) return true;
    if (b0 == 0x4F && b1 == 0x54 && b2 == 0x54 && b3 == 0x4F) return true;
    return false;
  }

  Future<(pw.Font, pw.Font)> _loadFontsSafe() async {
    // Try assets
    try {
      final regBD = await rootBundle.load('assets/fonts/NotoSans-Regular.ttf');
      final bldBD = await rootBundle.load('assets/fonts/NotoSans-Bold.ttf');
      final reg = regBD.buffer.asUint8List();
      final bld = bldBD.buffer.asUint8List();
      if (_isValidTtf(reg) && _isValidTtf(bld)) {
        return (pw.Font.ttf(regBD), pw.Font.ttf(bldBD));
      }
    } catch (_) {}
    // Try CDN
    try {
      final reg = await _fetchBytes('https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/notosans/NotoSans-Regular.ttf');
      final bld = await _fetchBytes('https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/notosans/NotoSans-Bold.ttf');
      if (_isValidTtf(reg) && _isValidTtf(bld)) {
        return (pw.Font.ttf(ByteData.sublistView(reg)), pw.Font.ttf(ByteData.sublistView(bld)));
      }
    } catch (_) {}
    // Fallback
    return (pw.Font.helvetica(), pw.Font.helveticaBold());
  }

  Future<Uint8List> _fetchBytes(String url) async {
    final resp = await html.HttpRequest.request(url, method: 'GET', responseType: 'arraybuffer');
    final buf = resp.response as ByteBuffer;
    return Uint8List.view(buf);
  }
  // --------------------------------

  pw.PageTheme _theme({bool landscape = false}) => pw.PageTheme(
    pageFormat: landscape ? PdfPageFormat.a4.landscape : PdfPageFormat.a4,
    margin: const pw.EdgeInsets.all(24),
  );

  List<pw.Widget> _detailedBlocks(List<Subitem> items, Map<String, List<Attachment>> attBySub, pw.Font fontBase, pw.Font fontBold) {
    final widgets = <pw.Widget>[];
    for (final s in items) {
      if (s.type == SubitemType.folder) {
        widgets.add(pw.Padding(padding: const pw.EdgeInsets.only(top: 12, bottom: 4), child: pw.Text('Папка: ${s.title}', style: pw.TextStyle(font: fontBold, fontSize: 16))));
        continue;
      }
      widgets.add(pw.Padding(padding: const pw.EdgeInsets.only(top: 12, bottom: 4), child: pw.Text('Подзадача: ${s.title}', style: pw.TextStyle(font: fontBold, fontSize: 14))));
      if (s.note != null && s.note!.trim().isNotEmpty) {
        widgets.add(pw.Padding(padding: const pw.EdgeInsets.only(bottom: 6), child: pw.Text(s.note!, style: pw.TextStyle(font: fontBase))));
      }
      final atts = attBySub[s.id] ?? const <Attachment>[];
      final images = atts.where((a) => a.mimeType.startsWith('image/')).toList();
      final others = atts.where((a) => !a.mimeType.startsWith('image/')).toList();

      if (images.isNotEmpty) {
        widgets.add(pw.Wrap(spacing: 8, runSpacing: 8, children: images.map((a) {
          final img = pw.MemoryImage(a.bytes);
          return pw.Container(width: 170, height: 128, decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey600, width: 0.5)), child: pw.ClipRRect(verticalRadius: 2, horizontalRadius: 2, child: pw.Image(img, fit: pw.BoxFit.cover)));
        }).toList()));
      }
      if (others.isNotEmpty) {
        widgets.add(pw.Padding(padding: const pw.EdgeInsets.only(top: 6), child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          pw.Text('Файлы:', style: pw.TextStyle(font: fontBold)),
          ...others.map((a) => pw.Text('• ${a.filename}', style: pw.TextStyle(font: fontBase))).toList(),
        ])));
      }
      widgets.add(pw.Divider());
    }
    return widgets;
  }
}
