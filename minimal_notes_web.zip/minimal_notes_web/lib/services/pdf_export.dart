import 'package:intl/intl.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';
import 'package:hive/hive.dart';
import 'package:pdf/google_fonts.dart' as gfonts;

import '../models/task.dart';
import '../models/subitem.dart';
import '../models/attachment.dart';

enum PdfVariant { checklist, detailed }

class PdfExporter {
  Future<void> exportTask(String taskId, PdfVariant variant, {int days = 28}) async {
    final tasks = Hive.box<Task>('tasks');
    final subs = Hive.box<Subitem>('subitems');
    final atts = Hive.box<Attachment>('attachments');

    final task = tasks.get(taskId)!;
    final subitems = subs.values.where((s) => s.taskId == taskId).toList()
      ..sort((a,b)=> a.createdAt.compareTo(b.createdAt));

    final attsBySub = <String, List<Attachment>>{};
    for (final s in subitems) {
      attsBySub[s.id] = atts.values.where((a) => a.subitemId == s.id).toList()
        ..sort((a,b)=> a.createdAt.compareTo(b.createdAt));
    }

    // Load Cyrillic-capable fonts (downloaded once from Google Fonts)
    final baseFont = await gfonts.PdfGoogleFonts.notoSansRegular();
    final boldFont = await gfonts.PdfGoogleFonts.notoSansBold();
    final theme = pw.ThemeData.withFont(base: baseFont, bold: boldFont);

    final doc = pw.Document();

    if (variant == PdfVariant.checklist) {
      final start = DateTime(task.createdAt.year, task.createdAt.month, task.createdAt.day);
      int generated = 0;
      while (generated < days) {
        final remain = days - generated;
        final span = remain >= 7 ? 7 : remain;
        final dates = List.generate(span, (i) => start.add(Duration(days: generated + i)));
        doc.addPage(
          pw.MultiPage(
            theme: theme,
            pageTheme: _theme(landscape: true),
            build: (ctx) => [
              pw.Header(
                level: 0,
                child: pw.Text('Чек-лист: ${task.title}', style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold)),
              ),
              pw.Text('Период: ${DateFormat('dd.MM').format(dates.first)} – ${DateFormat('dd.MM').format(dates.last)}'),
              pw.SizedBox(height: 10),
              _checklistTable(subitems.where((s)=>s.type == SubitemType.subtask).toList(), dates, theme),
            ],
          ),
        );
        generated += span;
      }
    } else {
      doc.addPage(
        pw.MultiPage(
          theme: theme,
          pageTheme: _theme(),
          build: (ctx) => [
            pw.Header(level: 0, child: pw.Text(task.title, style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold))),
            pw.Text('Экспорт: ${DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now())}'),
            pw.SizedBox(height: 12),
            ..._detailedBlocks(subitems, attsBySub, theme),
          ],
        ),
      );
    }

    final bytes = await doc.save();
    final fname = 'task_${task.title.replaceAll(' ', '_')}_${variant.name}.pdf';
    await Printing.sharePdf(bytes: bytes, filename: fname);
  }

  pw.PageTheme _theme({bool landscape = false}) {
    return pw.PageTheme(
      pageFormat: landscape ? PdfPageFormat.a4.landscape : PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(24),
    );
  }

  pw.Widget _checklistTable(List<Subitem> subtasks, List<DateTime> dates, pw.ThemeData theme) {
    final dateFmt = DateFormat('dd.MM');
    final headers = <pw.Widget>[
      pw.Container(
        padding: const pw.EdgeInsets.all(6),
        child: pw.Text('Подзадача', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
      ),
      ...dates.map((d) => pw.Center(child: pw.Text(dateFmt.format(d), style: const pw.TextStyle(fontSize: 10)))).toList(),
    ];

    final rows = subtasks.map<pw.TableRow>((s) {
      return pw.TableRow(
        children: [
          pw.Container(
            padding: const pw.EdgeInsets.all(6),
            child: pw.Text(s.title, maxLines: 1, overflow: pw.TextOverflow.span),
          ),
          ...dates.map((d) => pw.Container(
                height: 20,
                margin: const pw.EdgeInsets.symmetric(vertical: 4, horizontal: 2),
                decoration: pw.BoxDecoration(
                  border: pw.Border.all(color: PdfColors.grey600, width: 0.5),
                ),
              )),
        ],
      );
    }).toList();

    return pw.Table(
      border: pw.TableBorder.all(color: PdfColors.grey600, width: 0.6),
      defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
      columnWidths: {
        0: const pw.FlexColumnWidth(3),
        for (int i = 1; i <= dates.length; i++) i: const pw.FlexColumnWidth(1),
      },
      children: [
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: PdfColors.grey200),
          children: headers,
        ),
        ...rows,
      ],
    );
  }

  List<pw.Widget> _detailedBlocks(List<Subitem> items, Map<String, List<Attachment>> attBySub, pw.ThemeData theme) {
    final widgets = <pw.Widget>[];
    for (final s in items) {
      if (s.type == SubitemType.folder) {
        widgets.add(pw.Padding(
          padding: const pw.EdgeInsets.only(top: 12, bottom: 4),
          child: pw.Text('Папка: ${s.title}', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
        ));
        continue;
      }
      widgets.add(pw.Padding(
        padding: const pw.EdgeInsets.only(top: 12, bottom: 4),
        child: pw.Text('Подзадача: ${s.title}', style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
      ));
      if (s.note != null && s.note!.trim().isNotEmpty) {
        widgets.add(pw.Padding(
          padding: const pw.EdgeInsets.only(bottom: 6),
          child: pw.Text(s.note!),
        ));
      }
      final atts = attBySub[s.id] ?? const <Attachment>[];
      final images = atts.where((a) => a.mimeType.startsWith('image/')).toList();
      final others = atts.where((a) => !a.mimeType.startsWith('image/')).toList();

      if (images.isNotEmpty) {
        widgets.add(pw.Wrap(
          spacing: 8,
          runSpacing: 8,
          children: images.map((a) {
            final img = pw.MemoryImage(a.bytes);
            return pw.Container(
              width: 170,
              height: 128,
              decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey600, width: 0.5)),
              child: pw.ClipRRect(
                verticalRadius: 2,
                horizontalRadius: 2,
                child: pw.Image(img, fit: pw.BoxFit.cover),
              ),
            );
          }).toList(),
        ));
      }

      if (others.isNotEmpty) {
        widgets.add(pw.Padding(
          padding: const pw.EdgeInsets.only(top: 6),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text('Файлы:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
              ...others.map((a) => pw.Text('• ${a.filename}')).toList(),
            ],
          ),
        ));
      }

      widgets.add(pw.Divider());
    }
    return widgets;
  }
}
