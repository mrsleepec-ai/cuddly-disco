// GENERATED CODE - MANUAL (no build_runner)

part of 'attachment.dart';

class AttachmentAdapter extends TypeAdapter<Attachment> {
  @override
  final int typeId = 4;

  @override
  Attachment read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{};
    for (int i = 0; i < numOfFields; i++) {
      fields[reader.readByte()] = reader.read();
    }
    return Attachment(
      id: fields[0] as String,
      subitemId: fields[1] as String,
      filename: fields[2] as String,
      mimeType: fields[3] as String,
      bytes: fields[4] as Uint8List,
      createdAt: fields[5] as DateTime,
    );
  }

  @override
  void write(BinaryWriter writer, Attachment obj) {
    writer
      ..writeByte(6)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.subitemId)
      ..writeByte(2)
      ..write(obj.filename)
      ..writeByte(3)
      ..write(obj.mimeType)
      ..writeByte(4)
      ..write(obj.bytes)
      ..writeByte(5)
      ..write(obj.createdAt);
  }
}
