import 'dart:typed_data';
import 'package:hive/hive.dart';

part 'attachment.g.dart';

@HiveType(typeId: 4)
class Attachment extends HiveObject {
  @HiveField(0)
  String id;
  @HiveField(1)
  String subitemId;
  @HiveField(2)
  String filename;
  @HiveField(3)
  String mimeType;
  @HiveField(4)
  Uint8List bytes;
  @HiveField(5)
  DateTime createdAt;

  Attachment({
    required this.id,
    required this.subitemId,
    required this.filename,
    required this.mimeType,
    required this.bytes,
    required this.createdAt,
  });
}
