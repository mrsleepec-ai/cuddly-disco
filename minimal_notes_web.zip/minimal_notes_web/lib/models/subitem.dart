import 'package:hive/hive.dart';

part 'subitem.g.dart';

@HiveType(typeId: 2)
enum SubitemType {
  @HiveField(0)
  folder,
  @HiveField(1)
  subtask,
}

@HiveType(typeId: 3)
class Subitem extends HiveObject {
  @HiveField(0)
  String id;
  @HiveField(1)
  String taskId;
  @HiveField(2)
  String? parentFolderId;
  @HiveField(3)
  SubitemType type;
  @HiveField(4)
  String title;
  @HiveField(5)
  String? note;
  @HiveField(6)
  DateTime createdAt;

  Subitem({
    required this.id,
    required this.taskId,
    required this.parentFolderId,
    required this.type,
    required this.title,
    required this.note,
    required this.createdAt,
  });
}
