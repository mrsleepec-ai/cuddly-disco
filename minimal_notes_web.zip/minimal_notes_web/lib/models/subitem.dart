import 'package:hive/hive.dart';

part 'subitem.g.dart';

@HiveType(typeId: 2)
enum SubitemType {
  @HiveField(0)
  folder,
  @HiveField(1)
  subtask,
}

@HiveType(typeId: 3)
class Subitem extends HiveObject {
  @HiveField(0)
  String id;

  /// ID главной задачи
  @HiveField(1)
  String taskId;

  /// Если это дочерняя папка — ID родительской папки, иначе null
  @HiveField(2)
  String? parentFolderId;

  /// Тип элемента: папка или подзадача
  @HiveField(3)
  SubitemType type;

  /// Заголовок/название элемента
  @HiveField(4)
  String title;

  /// Примечание к подзадаче (опционально)
  @HiveField(5)
  String? note;

  /// Дата создания
  @HiveField(6)
  DateTime createdAt;

  /// Состояние чекбокса для подзадачи. Для папок не используется.
  @HiveField(7)
  bool isChecked;

  Subitem({
    required this.id,
    required this.taskId,
    required this.parentFolderId,
    required this.type,
    required this.title,
    required this.note,
    required this.createdAt,
    this.isChecked = false,
  });

  bool get isFolder => type == SubitemType.folder;
  bool get isSubtask => type == SubitemType.subtask;
}
