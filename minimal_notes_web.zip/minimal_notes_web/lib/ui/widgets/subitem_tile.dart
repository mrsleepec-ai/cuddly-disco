import 'package:flutter/material.dart';
import '../../models/subitem.dart';

class SubitemTile extends StatelessWidget {
  final Subitem subitem;
  final VoidCallback onOpen;
  final VoidCallback onRename;
  final VoidCallback onDelete;

  const SubitemTile({
    super.key,
    required this.subitem,
    required this.onOpen,
    required this.onRename,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onOpen,
      leading: subitem.isFolder
          ? const Icon(Icons.folder)
          : Checkbox(
              value: subitem.isChecked,
              onChanged: (v) async {
                subitem.isChecked = v ?? false;
                await subitem.save();
                // ignore: use_build_context_synchronously
                ScaffoldMessenger.of(context).hideCurrentSnackBar();
              },
            ),
      title: Text(subitem.title),
      subtitle: subitem.isSubtask && (subitem.note?.isNotEmpty == true)
          ? Text(subitem.note!)
          : null,
      trailing: PopupMenuButton<String>(
        onSelected: (value) async {
          switch (value) {
            case 'rename':
              onRename();
              break;
            case 'delete':
              onDelete();
              break;
          }
        },
        itemBuilder: (ctx) => const [
          PopupMenuItem(value: 'rename', child: Text('Переименовать')),
          PopupMenuItem(value: 'delete', child: Text('Удалить')),
        ],
      ),
    );
  }
}
