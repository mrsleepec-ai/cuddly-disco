import 'package:flutter/material.dart';
import '../../models/subitem.dart';

class SubitemTile extends StatelessWidget {
  final Subitem subitem;
  final bool done;
  final ValueChanged<bool>? onToggleDone;
  final VoidCallback onOpen;
  final VoidCallback onRename;
  final VoidCallback onDelete;
  final VoidCallback? onMoveToRoot;

  const SubitemTile({
    super.key,
    required this.subitem,
    required this.done,
    required this.onToggleDone,
    required this.onOpen,
    required this.onRename,
    required this.onDelete,
    this.onMoveToRoot,
  });

  @override
  Widget build(BuildContext context) {
    final isFolder = subitem.type == SubitemType.folder;
    return ListTile(
      leading: isFolder
          ? const Icon(Icons.folder)
          : Checkbox(
              value: done,
              onChanged: onToggleDone == null ? null : (v) => onToggleDone!(v ?? false),
            ),
      title: Text(
        subitem.title,
        style: (!isFolder && done) ? const TextStyle(decoration: TextDecoration.lineThrough) : null,
        overflow: TextOverflow.ellipsis,
      ),
      onTap: onOpen,
      trailing: PopupMenuButton<String>(
        onSelected: (key) {
          switch (key) {
            case 'rename':
              onRename();
              break;
            case 'delete':
              onDelete();
              break;
            case 'to_root':
              if (onMoveToRoot != null) onMoveToRoot!();
              break;
          }
        },
        itemBuilder: (ctx) => [
          const PopupMenuItem(value: 'rename', child: Text('Переименовать')),
          const PopupMenuItem(value: 'delete', child: Text('Удалить')),
          if (onMoveToRoot != null) const PopupMenuItem(value: 'to_root', child: Text('В корень')),
        ],
      ),
    );
  }
}
