import 'package:flutter/material.dart';
import '../../models/subitem.dart';

class SubitemTile extends StatelessWidget {
  final Subitem subitem;
  final VoidCallback onOpen;
  final ValueChanged<bool?> onToggleCompleted;
  final VoidCallback onRename;
  final VoidCallback onDelete;
  final VoidCallback onMove;

  const SubitemTile({
    super.key,
    required this.subitem,
    required this.onOpen,
    required this.onToggleCompleted,
    required this.onRename,
    required this.onDelete,
    required this.onMove,
  });

  @override
  Widget build(BuildContext context) {
    final isFolder = subitem.type == SubitemType.folder;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: ListTile(
        leading: isFolder
            ? const Icon(Icons.folder)
            : Checkbox(
                value: subitem.completed,
                onChanged: onToggleCompleted,
              ),
        title: Text(
          subitem.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: (!isFolder && subitem.completed)
              ? const TextStyle(decoration: TextDecoration.lineThrough, color: Colors.black54)
              : null,
        ),
        subtitle: isFolder ? const Text('Папка') : null,
        onTap: onOpen,
        trailing: PopupMenuButton<String>(
          onSelected: (v) {
            switch (v) {
              case 'rename':
                onRename();
                break;
              case 'move':
                onMove();
                break;
              case 'delete':
                onDelete();
                break;
            }
          },
          itemBuilder: (ctx) => [
            const PopupMenuItem(value: 'rename', child: Text('Переименовать')),
            if (!isFolder) const PopupMenuItem(value: 'move', child: Text('Переместить в папку')),
            const PopupMenuItem(value: 'delete', child: Text('Удалить')),
          ],
        ),
      ),
    );
  }
}
