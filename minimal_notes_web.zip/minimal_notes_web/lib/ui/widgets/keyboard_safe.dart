import 'package:flutter/material.dart';

/// Обёртка, стабилизирующая поведение клавиатуры на всех экранах.
class KeyboardSafe extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;

  const KeyboardSafe({
    super.key,
    required this.child,
    this.padding = EdgeInsets.zero,
  });

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => FocusScope.of(context).unfocus(),
      child: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            padding: padding.add(EdgeInsets.only(bottom: bottomInset)),
            child: ConstrainedBox(
              constraints: BoxConstraints(minHeight: constraints.maxHeight),
              child: child,
            ),
          );
        },
      ),
    );
  }
}
