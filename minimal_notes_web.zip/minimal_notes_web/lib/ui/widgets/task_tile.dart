import 'package:flutter/material.dart';
import '../../models/task.dart';

class TaskTile extends StatelessWidget {
  final Task task;
  final VoidCallback onOpen;
  final VoidCallback onRename;
  final VoidCallback onPdfCompact;
  final VoidCallback onPdfDetailed;
  final VoidCallback onDelete;
  const TaskTile({
    super.key,
    required this.task,
    required this.onOpen,
    required this.onRename,
    required this.onPdfCompact,
    required this.onPdfDetailed,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: ListTile(
        title: Text(task.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        onTap: onOpen,
        trailing: PopupMenuButton<String>(
          onSelected: (v) {
            switch (v) {
              case 'rename':
                onRename();
                break;
              case 'pdf_compact':
                onPdfCompact();
                break;
              case 'pdf_detailed':
                onPdfDetailed();
                break;
              case 'delete':
                onDelete();
                break;
            }
          },
          itemBuilder: (ctx) => [
            const PopupMenuItem(value: 'rename', child: Text('Переименовать')),
            const PopupMenuItem(value: 'pdf_compact', child: Text('PDF: Компактный')),
            const PopupMenuItem(value: 'pdf_detailed', child: Text('PDF: Детальный')),
            const PopupMenuItem(value: 'delete', child: Text('Удалить')),
          ],
        ),
      ),
    );
  }
}
