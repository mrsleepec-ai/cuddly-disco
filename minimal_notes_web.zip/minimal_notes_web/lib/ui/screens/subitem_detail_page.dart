import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../services/repository.dart';
import '../widgets/keyboard_safe.dart';

class SubitemDetailPage extends ConsumerStatefulWidget {
  final String subitemId;
  final String title;
  const SubitemDetailPage({super.key, required this.subitemId, required this.title});

  @override
  ConsumerState<SubitemDetailPage> createState() => _SubitemDetailPageState();
}

class _SubitemDetailPageState extends ConsumerState<SubitemDetailPage> {
  final noteCtl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final repo = ref.read(repoProvider);
    final sub = await repo.readSubitem(widget.subitemId);
    if (!mounted) return;
    noteCtl.text = sub?.note ?? '';
    setState(() {});
  }

  @override
  void dispose() {
    noteCtl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(repoProvider);
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          TextButton(
            onPressed: () async {
              await repo.updateNote(widget.subitemId, noteCtl.text);
              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Сохранено')));
            },
            child: const Text('Сохранить'),
          ),
        ],
      ),
      body: KeyboardSafe(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: noteCtl,
              minLines: 5,
              maxLines: 12,
              decoration: const InputDecoration(hintText: 'Заметка к подзадаче'),
              scrollPadding: const EdgeInsets.only(bottom: 120),
              textInputAction: TextInputAction.newline,
              keyboardType: TextInputType.multiline,
            ),
          ],
        ),
      ),
    );
  }
}
