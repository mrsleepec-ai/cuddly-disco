import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../services/repository.dart';
import '../../services/file_service.dart';
import '../../models/attachment.dart';
import '../../utils/web_open_stub.dart'
  if (dart.library.html) '../../utils/web_open_web.dart';
import 'home_page.dart';

class SubitemDetailPage extends ConsumerStatefulWidget {
  final String subitemId;
  final String title;
  const SubitemDetailPage({super.key, required this.subitemId, required this.title});

  @override
  ConsumerState<SubitemDetailPage> createState() => _SubitemDetailPageState();
}

class _SubitemDetailPageState extends ConsumerState<SubitemDetailPage> {
  final noteCtl = TextEditingController();
  final fileService = FileService();

void _openImageViewer(Uint8List bytes, {String? tag}) {
  showDialog(
    context: context,
    barrierColor: Colors.black87,
    builder: (_) {
      return GestureDetector(
        onTap: () => Navigator.of(context).pop(),
        child: Material(
          color: Colors.black,
          child: SafeArea(
            child: Center(
              child: InteractiveViewer(
                child: tag == null
                    ? Image.memory(bytes)
                    : Hero(tag: tag, child: Image.memory(bytes)),
              ),
            ),
          ),
        ),
      );
    },
  );
}


  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final repo = ref.read(repoProvider);
    final sub = await repo.readSubitem(widget.subitemId);
    if (sub != null) {
      noteCtl.text = sub.note ?? '';
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(repoProvider);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          TextButton(
            onPressed: () async {
              await repo.updateNote(widget.subitemId, noteCtl.text);
              if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Сохранено')));
            },
            child: const Text('Сохранить'),
          )
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: noteCtl,
              minLines: 5,
              maxLines: 12,
              decoration: const InputDecoration(hintText: 'Заметка к подзадаче'),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              FilledButton.tonal(
                onPressed: () async {
                  try {
                    final (bytes, name, mime) = await fileService.pickFromCamera();
                    await repo.addAttachment(subitemId: widget.subitemId, filename: name, mimeType: mime, bytes: bytes);
                    setState(() {});
                  } catch (_) {}
                },
                child: const Text('Камера'),
              ),
              FilledButton.tonal(
                onPressed: () async {
                  try {
                    final (bytes, name, mime) = await fileService.pickFromGallery();
                    await repo.addAttachment(subitemId: widget.subitemId, filename: name, mimeType: mime, bytes: bytes);
                    setState(() {});
                  } catch (_) {}
                },
                child: const Text('Галерея'),
              ),
              FilledButton(
                onPressed: () async {
                  try {
                    final (bytes, name, mime) = await fileService.pickFromFiles();
                    await repo.addAttachment(subitemId: widget.subitemId, filename: name, mimeType: mime, bytes: bytes);
                    setState(() {});
                  } catch (_) {}
                },
                child: const Text('Файлы'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: FutureBuilder<List<Attachment>>(
              future: repo.listAttachments(widget.subitemId),
              builder: (context, snapshot) {
                final atts = snapshot.data ?? const <Attachment>[];
                if (atts.isEmpty) return const Center(child: Text('Вложений нет'));
                return ListView.separated(
                  itemCount: atts.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (ctx, i) {
                    final a = atts[i];
                    return ListTile(
                      leading: a.mimeType.startsWith('image/')
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Hero(
                                tag: 'att_'+a.id,
                                child: Image.memory(a.bytes, width: 72, height: 72, fit: BoxFit.cover),
                              ),
                            )
                          : const Icon(Icons.attachment),
                      title: Text(a.filename),
                      subtitle: Text(a.mimeType),
                      onTap: () {
                        if (a.mimeType.startsWith('image/')) {
                          _openImageViewer(a.bytes, tag: 'att_'+a.id);
                        } else {
                          WebOpen.openBytes(a.bytes, a.mimeType, a.filename);
                        }
                      },
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          await repo.removeAttachment(a.id);
                          setState(() {});
                        },
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}


void _openImageGallery(List<Attachment> atts, int initial) {
  final images = atts.where((e) => e.mimeType.startsWith('image/')).toList();
  int currentIndex = images.indexWhere((e) => e.id == atts[initial].id);
  if (currentIndex == -1) currentIndex = 0;
  final controller = PageController(initialPage: currentIndex);
  showDialog(
    context: context,
    barrierColor: Colors.black87,
    builder: (_) {
      return StatefulBuilder(
        builder: (context, setState) {
          return Material(
            color: Colors.black,
            child: SafeArea(
              child: Stack(
                children: [
                  PageView.builder(
                    controller: controller,
                    itemCount: images.length,
                    onPageChanged: (i) => setState(() {}),
                    itemBuilder: (_, i) {
                      final img = images[i];
                      return Center(
                        child: InteractiveViewer(
                          child: Hero(tag: 'att_'+img.id, child: Image.memory(img.bytes)),
                        ),
                      );
                    },
                  ),
                  Positioned(
                    top: 8, left: 8,
                    child: IconButton(
                      icon: const Icon(Icons.close, color: Colors.white),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}
