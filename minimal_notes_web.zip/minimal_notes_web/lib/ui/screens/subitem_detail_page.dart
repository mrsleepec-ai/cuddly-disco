import 'package:flutter/material.dart';
import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../services/repository.dart';
import '../../services/file_service.dart';
import '../../models/attachment.dart';
import '../../utils/web_open_stub.dart'
  if (dart.library.html) '../../utils/web_open_web.dart';
import 'home_page.dart';

class SubitemDetailPage extends ConsumerStatefulWidget {
  final String subitemId;
  final String title;
  const SubitemDetailPage({super.key, required this.subitemId, required this.title});

  @override
  ConsumerState<SubitemDetailPage> createState() => _SubitemDetailPageState();
}

class _SubitemDetailPageState extends ConsumerState<SubitemDetailPage> {
  Timer? _debounce;
  bool _saving = false;
  String _status = '';
  void _scheduleAutoSave() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 800), () async {
      if (!mounted) return;
      setState(() { _saving = true; _status = 'Сохранение…'; });
      await ref.read(repoProvider).updateNote(widget.subitemId, noteCtl.text);
      if (!mounted) return;
      setState(() { _saving = false; _status = 'Сохранено'; });
      Future.delayed(const Duration(seconds: 1), () { if (mounted) setState(() { _status = ''; }); });
    });
  }

  final noteCtl = TextEditingController();
  final fileService = FileService();

  @override
  void initState() {
    super.initState();
    _load();
    noteCtl.addListener(_scheduleAutoSave);
  }

  Future<void> _load() async {
    final repo = ref.read(repoProvider);
    final sub = await repo.readSubitem(widget.subitemId);
    if (sub != null) {
      noteCtl.text = sub.note ?? '';
      setState(() {});
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    // fire-and-forget final save
    final text = noteCtl.text;
    // ignore: discarded_futures
    ref.read(repoProvider).updateNote(widget.subitemId, text);
    noteCtl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(repoProvider);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
  Padding(
    padding: const EdgeInsets.only(right: 12),
    child: _saving
        ? SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
        : (_status.isNotEmpty ? Center(child: Text(_status)) : SizedBox.shrink()),
  )
],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: noteCtl,
              minLines: 5,
              maxLines: 12,
              decoration: const InputDecoration(hintText: 'Заметка к подзадаче'),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              FilledButton.tonal(
                onPressed: () async {
                  try {
                    final (bytes, name, mime) = await fileService.pickFromCamera();
                    await repo.addAttachment(subitemId: widget.subitemId, filename: name, mimeType: mime, bytes: bytes);
                    setState(() {});
                  } catch (_) {}
                },
                child: const Text('Камера'),
              ),
              FilledButton.tonal(
                onPressed: () async {
                  try {
                    final (bytes, name, mime) = await fileService.pickFromGallery();
                    await repo.addAttachment(subitemId: widget.subitemId, filename: name, mimeType: mime, bytes: bytes);
                    setState(() {});
                  } catch (_) {}
                },
                child: const Text('Галерея'),
              ),
              FilledButton(
                onPressed: () async {
                  try {
                    final (bytes, name, mime) = await fileService.pickFromFiles();
                    await repo.addAttachment(subitemId: widget.subitemId, filename: name, mimeType: mime, bytes: bytes);
                    setState(() {});
                  } catch (_) {}
                },
                child: const Text('Файлы'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: FutureBuilder<List<Attachment>>(
              future: repo.listAttachments(widget.subitemId),
              builder: (context, snapshot) {
                final atts = snapshot.data ?? const <Attachment>[];
                if (atts.isEmpty) return const Center(child: Text('Вложений нет'));
                return GridView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 8,
                    crossAxisSpacing: 8,
                    childAspectRatio: 0.75,
                  ),
                  itemCount: atts.length,
                  itemBuilder: (ctx, i) {
                    final a = atts[i];
                    final isImage = a.mimeType.startsWith('image/');
                    return Material(
                      color: Colors.white,
                      elevation: 1,
                      borderRadius: BorderRadius.circular(8),
                      child: InkWell(
                        onTap: () => WebOpen.openBytes(a.bytes, a.mimeType, a.filename),
                        child: Column(
                          children: [
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.all(6),
                                child: isImage
                                    ? ClipRRect(
                                        borderRadius: BorderRadius.circular(6),
                                        child: Image.memory(a.bytes, fit: BoxFit.cover, width: double.infinity, height: double.infinity),
                                      )
                                    : Center(child: Icon(_iconFor(a.mimeType))),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      a.filename,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontSize: 12),
                                    ),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.delete_outline, size: 18),
                                    onPressed: () async {
                                      await repo.removeAttachment(a.id);
                                      (context as Element).markNeedsBuild();
                                    },
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

IconData _iconFor(String mime) {
  if (mime.contains('pdf')) return Icons.picture_as_pdf;
  if (mime.contains('text')) return Icons.description_outlined;
  return Icons.insert_drive_file_outlined;
}
