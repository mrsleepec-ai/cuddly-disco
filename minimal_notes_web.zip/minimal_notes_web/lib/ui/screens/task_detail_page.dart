import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models/subitem.dart';
import '../../services/repository.dart';
import '../../utils/dialogs.dart';
import '../widgets/subitem_tile.dart';
import 'subitem_detail_page.dart';
import 'home_page.dart';

class TaskDetailPage extends ConsumerStatefulWidget {
  final String taskId;
  final String taskTitle;
  final String? parentFolderId;

  const TaskDetailPage({super.key, required this.taskId, required this.taskTitle, this.parentFolderId});

  @override
  ConsumerState<TaskDetailPage> createState() => _TaskDetailPageState();
}

class _TaskDetailPageState extends ConsumerState<TaskDetailPage> {
  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(repoProvider);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.taskTitle),
      ),
      body: FutureBuilder<List<Subitem>>(
        future: repo.listSubitems(taskId: widget.taskId, parentFolderId: widget.parentFolderId),
        builder: (context, snapshot) {
          final items = snapshot.data ?? const <Subitem>[];
          return Column(
            children: [
              // Заголовок с чекбоксом задачи
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Row(
                  children: [
                    StatefulBuilder(builder: (c, setSt) {
                      final r = ref.read(repoProvider);
                      final done = r.isTaskDone(widget.taskId);
                      return Checkbox(value: done, onChanged: (v) async { await r.setTaskDone(widget.taskId, v ?? false); if (mounted) setState(() {}); });
                    }),
                    Expanded(child: Text(widget.taskTitle, style: Theme.of(context).textTheme.titleMedium, overflow: TextOverflow.ellipsis)),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
              // Заголовок с чекбоксом задачи
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Row(
                  children: [
                    StatefulBuilder(builder: (c, setSt) {
                      final r = ref.read(repoProvider);
                      final done = r.isTaskDone(widget.taskId);
                      return Checkbox(value: done, onChanged: (v) async { await r.setTaskDone(widget.taskId, v ?? false); if (mounted) setState(() {}); });
                    }),
                    Expanded(child: Text(widget.taskTitle, style: Theme.of(context).textTheme.titleMedium, overflow: TextOverflow.ellipsis)),
                  ],
                ),
              ),
                  FilledButton.tonal(
                    onPressed: () async {
                      final v = await promptText(context, title: 'Название папки');
                      if (v != null && v.isNotEmpty) {
                        await ref.read(repoProvider).createFolder(widget.taskId, parentFolderId: widget.parentFolderId, title: v);
                        setState(() {});
                      }
                    },
                    child: const Text('Создать папку'),
                  ),
                  FilledButton(
                    onPressed: () async {
                      final v = await promptText(context, title: 'Название подзадачи');
                      if (v != null && v.isNotEmpty) {
                        await ref.read(repoProvider).createSubtask(widget.taskId, parentFolderId: widget.parentFolderId, title: v);
                        setState(() {});
                      }
                    },
                    child: const Text('Создать подзадачу'),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: items.isEmpty
                    ? const Center(child: Text('Нет элементов'))
                    : ListView.builder(
                        itemCount: items.length,
                        itemBuilder: (ctx, i) {
                          final s = items[i];
                          return SubitemTile(
                            subitem: s,
                            done: ref.read(repoProvider).isSubitemDone(s.id),
                            onToggleDone: s.type == SubitemType.subtask ? (v) async { final r = ref.read(repoProvider); await r.setSubitemDone(s.id, v); await r.recomputeTaskDoneFromSubs(widget.taskId); if (mounted) setState(() {}); } : null,
                            onOpen: () {
                              if (s.type == SubitemType.folder) {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => TaskDetailPage(
                                      taskId: widget.taskId,
                                      taskTitle: s.title,
                                      parentFolderId: s.id,
                                    ),
                                  ),
                                );
                              } else {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => SubitemDetailPage(subitemId: s.id, title: s.title)),
                                );
                              }
                            },
                            onRename: () async {
                              final v = await promptText(context, title: 'Переименовать', initial: s.title);
                              if (v != null && v.isNotEmpty) {
                                await ref.read(repoProvider).renameSubitem(s.id, v);
                                setState(() {});
                              }
                            },
                            onDelete: () async {
                              final ok = await confirm(context, text: 'Удалить "${s.title}"?');
                              if (ok) {
                                await ref.read(repoProvider).deleteSubitem(s.id);
                                setState(() {});
                              }
                            },
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}
