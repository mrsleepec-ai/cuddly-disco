import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models/subitem.dart';
import '../../services/repository.dart';
import '../../utils/dialogs.dart';
import '../widgets/subitem_tile.dart';
import 'subitem_detail_page.dart';
import 'home_page.dart';

class TaskDetailPage extends ConsumerStatefulWidget {
  final String taskId;
  final String taskTitle;
  final String? parentFolderId;

  const TaskDetailPage({super.key, required this.taskId, required this.taskTitle, this.parentFolderId});
                            });

  @override
  ConsumerState<TaskDetailPage> createState() => _TaskDetailPageState();
}

class _TaskDetailPageState extends ConsumerState<TaskDetailPage> {
  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(repoProvider);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.taskTitle),
      ),
      body: FutureBuilder<List<Subitem>>(
        future: repo.listSubitems(taskId: widget.taskId, parentFolderId: widget.parentFolderId),
        builder: (context, snapshot) {
          final items = snapshot.data ?? const <Subitem>[];
          return Column(
            children: [
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  FilledButton.tonal(
                    onPressed: () async {
                      final v = await promptText(context, title: 'Название папки');
                      if (v != null && v.isNotEmpty) {
                        await ref.read(repoProvider).createFolder(widget.taskId, parentFolderId: widget.parentFolderId, title: v);
                        setState(() {});
                      }
                    },
                    child: const Text('Создать папку'),
                  ),
                  FilledButton(
                    onPressed: () async {
                      final v = await promptText(context, title: 'Название подзадачи');
                      if (v != null && v.isNotEmpty) {
                        await ref.read(repoProvider).createSubtask(widget.taskId, parentFolderId: widget.parentFolderId, title: v);
                        setState(() {});
                      }
                    },
                    child: const Text('Создать подзадачу'),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: items.isEmpty
                    ? const Center(child: Text('Нет элементов'))
                    : ListView.builder(
                        itemCount: items.length,
                        itemBuilder: (ctx, i) {
                          final s = items[i];
                          return FutureBuilder<bool>(
                            future: s.type == SubitemType.subtask ? ref.read(repoProvider).isSubitemDone(s.id) : Future.value(false),
                            builder: (ctx, snap) {
                              final sDone = (s.type == SubitemType.subtask) ? (snap.data ?? false) : false;
                              return SubitemTile(
                            subitem: s,
                            isDone: sDone,
                            onToggleDone: s.type == SubitemType.subtask ? (v) async {
                              await ref.read(repoProvider).toggleSubitemDone(s.id, v ?? false);
                              await ref.read(repoProvider).autoTaskDoneFromSubitems(widget.taskId);
                              setState(() {});
                            } : null,
                            onMove: s.type == SubitemType.subtask ? () async {
                              // pick folder
                              final folders = await ref.read(repoProvider).listSubitems(taskId: widget.taskId, parentFolderId: widget.parentFolderId);
                              final folderList = folders.where((x)=> x.type == SubitemType.folder).toList();
                              String? chosen;
                              await showDialog(context: context, builder: (ctx){
                                return AlertDialog(title: const Text('Переместить в папку'), content: SizedBox(width: 300, child: ListView(
                                  shrinkWrap: true,
                                  children: [
                                    ListTile(title: const Text('Без папки'), onTap: () { chosen = null; Navigator.pop(ctx); }),
                                    ...folderList.map((f)=> ListTile(title: Text(f.title), onTap: () { chosen = f.id; Navigator.pop(ctx); })),
                                  ],)),);
                              });
                              await ref.read(repoProvider).moveSubitem(subitemId: s.id, newParentFolderId: chosen);
                              setState(() {});
                            } : null,
                            onAttach: s.type == SubitemType.subtask ? () async {
                              // open detail page to attach
                              Navigator.push(context, MaterialPageRoute(builder: (_)=> SubitemDetailPage(subitemId: s.id, title: s.title)));
                            } : null,
                            onOpen: () {
                              if (s.type == SubitemType.folder) {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => TaskDetailPage(
                                      taskId: widget.taskId,
                                      taskTitle: s.title,
                                      parentFolderId: s.id,
                                    ),
                                  ),
                                );
                              } else {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => SubitemDetailPage(subitemId: s.id, title: s.title)),
                                );
                              }
                            },
                            onRename: () async {
                              final v = await promptText(context, title: 'Переименовать', initial: s.title);
                              if (v != null && v.isNotEmpty) {
                                await ref.read(repoProvider).renameSubitem(s.id, v);
                                setState(() {});
                              }
                            },
                            onMove: s.type == SubitemType.subtask ? () async {
                              // выбрать папку из текущего списка
                              final list = await ref.read(repoProvider).listSubitems(taskId: widget.taskId, parentFolderId: widget.parentFolderId);
                              final folders = list.where((x) => x.type == SubitemType.folder).toList();
                              final picked = await showModalBottomSheet<String>(context: context, builder: (ctx){
                                return ListView(
                                  children: [
                                    ListTile(title: const Text('Вверх (в корень)'), onTap: ()=> Navigator.pop(ctx, null)),
                                    ...folders.map((f) => ListTile(title: Text(f.title), onTap: ()=> Navigator.pop(ctx, f.id))).toList(),
                                  ],
                                );
                              });
                              if (picked != null || true) {
                                await ref.read(repoProvider).moveSubitem(subitemId: s.id, newParentFolderId: picked);
                                setState(() {});
                              }
                            } : null,
                            onAttach: s.type == SubitemType.subtask ? () async {
                              if (mounted) {
                                await Navigator.push(context, MaterialPageRoute(builder: (_)=> SubitemDetailPage(subitemId: s.id, title: s.title)));
                                setState(() {});
                              }
                            } : null,
                            onDelete: () async {
                              final ok = await confirm(context, text: 'Удалить "${s.title}"?');
                              if (ok) {
                                await ref.read(repoProvider).deleteSubitem(s.id);
                                setState(() {});
                              }
                            },
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}
