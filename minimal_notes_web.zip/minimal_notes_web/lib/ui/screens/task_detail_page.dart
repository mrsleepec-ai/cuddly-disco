import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models/subitem.dart';
import '../../services/repository.dart';
import '../../utils/dialogs.dart';
import '../widgets/subitem_tile.dart';
import 'subitem_detail_page.dart';
import 'home_page.dart';

class TaskDetailPage extends ConsumerStatefulWidget {
  final String taskId;
  final String taskTitle;
  final String? parentFolderId;

  const TaskDetailPage({super.key, required this.taskId, required this.taskTitle, this.parentFolderId});

  @override
  ConsumerState<TaskDetailPage> createState() => _TaskDetailPageState();
}

class _TaskDetailPageState extends ConsumerState<TaskDetailPage> {
  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(repoProvider);
    final atRoot = widget.parentFolderId == null;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.taskTitle, overflow: TextOverflow.ellipsis),
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.of(context).pop()),
        actions: [
          IconButton(
            tooltip: 'Новая папка',
            icon: const Icon(Icons.create_new_folder_outlined),
            onPressed: () async {
              final v = await promptText(context, title: 'Новая папка');
              if (v != null && v.trim().isNotEmpty) {
                await ref.read(repoProvider).createFolder(widget.taskId, title: v.trim(), parentFolderId: widget.parentFolderId);
                if (mounted) setState(() {});
              }
            },
          ),
          IconButton(
            tooltip: 'Новая подзадача',
            icon: const Icon(Icons.playlist_add),
            onPressed: () async {
              final v = await promptText(context, title: 'Новая подзадача');
              if (v != null && v.trim().isNotEmpty) {
                await ref.read(repoProvider).createSubtask(widget.taskId, title: v.trim(), parentFolderId: widget.parentFolderId);
                if (mounted) setState(() {});
              }
            },
          ),
        ],
      ),
      body: FutureBuilder<List<Subitem>>(
        future: repo.listSubitems(taskId: widget.taskId, parentFolderId: widget.parentFolderId),
        builder: (context, snap) {
          final items = snap.data ?? const <Subitem>[];

          return Column(
            children: [
              if (!atRoot)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  color: Theme.of(context).colorScheme.surfaceContainerHighest,
                  child: Row(
                    children: [
                      TextButton.icon(
                        onPressed: () => Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (_) => TaskDetailPage(taskId: widget.taskId, taskTitle: widget.taskTitle, parentFolderId: null),
                        )),
                        icon: const Icon(Icons.arrow_upward),
                        label: const Text('К корню'),
                      ),
                      const Spacer(),
                      const Text('Перетащите подзадачу на папку, чтобы переместить'),
                    ],
                  ),
                ),
              Expanded(
                child: snap.connectionState == ConnectionState.waiting
                    ? const Center(child: CircularProgressIndicator())
                    : items.isEmpty
                        ? const Center(child: Text('Нет элементов'))
                        : ListView.separated(
                            itemCount: items.length,
                            separatorBuilder: (_, __) => const Divider(height: 1),
                            itemBuilder: (ctx, i) {
                              final s = items[i];
                              final isFolder = s.type == SubitemType.folder;

                              Widget tile = SubitemTile(
                                subitem: s,
                                done: !isFolder && ref.read(repoProvider).isSubitemDone(s.id),
                                onToggleDone: isFolder ? null : (v) async {
                                  final r = ref.read(repoProvider);
                                  await r.setSubitemDone(s.id, v);
                                  await r.recomputeTaskDoneFromSubs(widget.taskId);
                                  if (mounted) setState(() {});
                                },
                                onOpen: () {
                                  if (isFolder) {
                                    Navigator.push(context, MaterialPageRoute(
                                      builder: (_) => TaskDetailPage(taskId: widget.taskId, taskTitle: widget.taskTitle, parentFolderId: s.id),
                                    ));
                                  } else {
                                    Navigator.push(context, MaterialPageRoute(
                                      builder: (_) => SubitemDetailPage(subitemId: s.id, title: s.title),
                                    ));
                                  }
                                },
                                onRename: () async {
                                  final v = await promptText(context, title: 'Переименовать', initial: s.title);
                                  if (v != null && v.isNotEmpty) {
                                    await ref.read(repoProvider).renameSubitem(s.id, v);
                                    if (mounted) setState(() {});
                                  }
                                },
                                onDelete: () async {
                                  final ok = await confirm(context, text: 'Удалить "${s.title}"?');
                                  if (ok) {
                                    await ref.read(repoProvider).deleteSubitem(s.id);
                                    await ref.read(repoProvider).recomputeTaskDoneFromSubs(widget.taskId);
                                    if (mounted) setState(() {});
                                  }
                                },
                                onMoveToRoot: (!atRoot && !isFolder) ? () async {
                                  await ref.read(repoProvider).moveSubitem(s.id, parentFolderId: null);
                                  if (mounted) setState(() {});
                                } : null,
                              );

                              if (isFolder) {
                                tile = DragTarget<Subitem>(
                                  onWillAccept: (data) => data != null && data.type == SubitemType.subtask,
                                  onAccept: (data) async {
                                    await ref.read(repoProvider).moveSubitem(data.id, parentFolderId: s.id);
                                    if (mounted) setState(() {});
                                  },
                                  builder: (context, candidateData, rejected) {
                                    final hovering = candidateData.isNotEmpty;
                                    return DecoratedBox(
                                      decoration: BoxDecoration(
                                        color: hovering ? Theme.of(context).colorScheme.primary.withOpacity(0.06) : null,
                                      ),
                                      child: tile,
                                    );
                                  },
                                );
                              } else {
                                tile = LongPressDraggable<Subitem>(
                                  data: s,
                                  feedback: Material(
                                    elevation: 6,
                                    borderRadius: BorderRadius.circular(8),
                                    child: ConstrainedBox(
                                      constraints: const BoxConstraints(maxWidth: 280),
                                      child: ListTile(
                                        leading: const Icon(Icons.check_box_outline_blank),
                                        title: Text(s.title, overflow: TextOverflow.ellipsis),
                                      ),
                                    ),
                                  ),
                                  childWhenDragging: Opacity(opacity: 0.5, child: tile),
                                  dragAnchorStrategy: childDragAnchorStrategy,
                                  child: tile,
                                );
                              }

                              return tile;
                            },
                          ),
              ),
            ],
          );
        },
      ),
    );
  }
}
