import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models/subitem.dart';
import '../../services/repository.dart';
import '../../utils/dialogs.dart';
import '../widgets/subitem_tile.dart';
import 'subitem_detail_page.dart';
import 'home_page.dart';

class TaskDetailPage extends ConsumerStatefulWidget {
  final String taskId;
  final String taskTitle;
  final String? parentFolderId;

  const TaskDetailPage({super.key, required this.taskId, required this.taskTitle, this.parentFolderId});

  @override
  ConsumerState<TaskDetailPage> createState() => _TaskDetailPageState();
}

class _TaskDetailPageState extends ConsumerState<TaskDetailPage> {
  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(repoProvider);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.taskTitle),
      ),
      body: FutureBuilder<List<Subitem>>(
        future: repo.listSubitems(taskId: widget.taskId, parentFolderId: widget.parentFolderId),
        builder: (context, snapshot) {
          final items = snapshot.data ?? const <Subitem>[];
          return Column(
            children: [
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  FilledButton.tonal(
                    onPressed: () async {
                      final v = await promptText(context, title: 'Название папки');
                      if (v != null && v.isNotEmpty) {
                        await ref.read(repoProvider).createFolder(widget.taskId, parentFolderId: widget.parentFolderId, title: v);
                        setState(() {});
                      }
                    },
                    child: const Text('Создать папку'),
                  ),
                  FilledButton(
                    onPressed: () async {
                      final v = await promptText(context, title: 'Название подзадачи');
                      if (v != null && v.isNotEmpty) {
                        await ref.read(repoProvider).createSubtask(widget.taskId, parentFolderId: widget.parentFolderId, title: v);
                        setState(() {});
                      }
                    },
                    child: const Text('Создать подзадачу'),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: items.isEmpty
                    ? const Center(child: Text('Нет элементов'))
                    : ListView.builder(
                        itemCount: items.length,
                        itemBuilder: (ctx, i) {
                          final s = items[i];
                          return SubitemTile(
                            subitem: s,
                            onOpen: () {
                              if (s.type == SubitemType.folder) {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => TaskDetailPage(
                                      taskId: widget.taskId,
                                      taskTitle: s.title,
                                      parentFolderId: s.id,
                                    ),
                                  ),
                                );
                              } else {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => SubitemDetailPage(subitemId: s.id, title: s.title)),
                                );
                              }
                            },
                            onToggleCompleted: (v) async {
                              await ref.read(repoProvider).setSubitemCompleted(s.id, v ?? false);
                              setState(() {});
                            },
                            onRename: () async {
                              final v = await promptText(context, title: 'Переименовать', initial: s.title);
                              if (v != null && v.isNotEmpty) {
                                await ref.read(repoProvider).renameSubitem(s.id, v);
                                setState(() {});
                              }
                            },
                            onMove: () async {
                              final folders = await ref.read(repoProvider).listAllFolders(widget.taskId);
                              final opts = folders.map<(String,String)>((f) => (f.id, f.title)).toList();
                              final target = await chooseFolder(context, title: 'Переместить в папку', options: opts);
                              if (target != null) {
                                await ref.read(repoProvider).moveSubitem(s.id, target == 'root' ? null : target);
                                setState(() {});
                              }
                            },
                            onDelete: () async {
                              final ok = await confirm(context, text: 'Удалить "${s.title}"?');
                              if (ok) {
                                await ref.read(repoProvider).deleteSubitem(s.id);
                                setState(() {});
                              }
                            },
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}
