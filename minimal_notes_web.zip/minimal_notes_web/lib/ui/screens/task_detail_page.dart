import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models/subitem.dart';
import '../../services/repository.dart';
import '../../utils/dialogs.dart';
import '../widgets/subitem_tile.dart';
import '../widgets/keyboard_safe.dart';
import 'subitem_detail_page.dart';

enum SubitemFilter { all, checked, unchecked }

class TaskDetailPage extends ConsumerStatefulWidget {
  final String taskId;
  final String taskTitle;
  final String? parentFolderId;

  const TaskDetailPage({
    super.key,
    required this.taskId,
    required this.taskTitle,
    this.parentFolderId,
  });

  @override
  ConsumerState<TaskDetailPage> createState() => _TaskDetailPageState();
}

class _TaskDetailPageState extends ConsumerState<TaskDetailPage> {
  SubitemFilter _filter = SubitemFilter.all;

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(repoProvider);

    final items = repo.subitemsSync(taskId: widget.taskId, parentFolderId: widget.parentFolderId);
    final filtered = items.where((s) {
      if (s.isFolder) return true; // всегда видеть папки
      switch (_filter) {
        case SubitemFilter.checked:
          return s.isSubtask && s.isChecked == true;
        case SubitemFilter.unchecked:
          return s.isSubtask && (s.isChecked != true);
        case SubitemFilter.all:
        default:
          return true;
      }
    }).toList();

    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(title: Text(widget.taskTitle)),
      body: Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Column(
          children: [
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                FilledButton.tonal(
                  onPressed: () async {
                    final v = await promptText(context, title: 'Название папки');
                    if (v != null && v.isNotEmpty) {
                      await ref.read(repoProvider).createFolder(
                        widget.taskId,
                        parentFolderId: widget.parentFolderId,
                        title: v,
                      );
                      if (mounted) setState(() {});
                    }
                  },
                  child: const Text('Создать папку'),
                ),
                FilledButton(
                  onPressed: () async {
                    final v = await promptText(context, title: 'Название подзадачи');
                    if (v != null && v.isNotEmpty) {
                      await ref.read(repoProvider).createSubtask(
                        widget.taskId,
                        parentFolderId: widget.parentFolderId,
                        title: v,
                      );
                      if (mounted) setState(() {});
                    }
                  },
                  child: const Text('Создать подзадачу'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Text('Фильтр:'),
                const SizedBox(width: 8),
                DropdownButton<SubitemFilter>(
                  value: _filter,
                  onChanged: (v) => setState(() => _filter = v ?? SubitemFilter.all),
                  items: const [
                    DropdownMenuItem(value: SubitemFilter.all, child: Text('Все')),
                    DropdownMenuItem(value: SubitemFilter.checked, child: Text('С галочкой')),
                    DropdownMenuItem(value: SubitemFilter.unchecked, child: Text('Без галочки')),
                  ],
                ),
              ],
            ),
            Expanded(
              child: filtered.isEmpty
                  ? const Center(child: Text('Нет элементов'))
                  : ListView.builder(
                      itemCount: filtered.length,
                      itemBuilder: (ctx, i) {
                        final s = filtered[i];
                        return SubitemTile(
                          subitem: s,
                          onOpen: () async {
                            if (s.isFolder) {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => TaskDetailPage(
                                    taskId: widget.taskId,
                                    taskTitle: widget.taskTitle,
                                    parentFolderId: s.id,
                                  ),
                                ),
                              );
                            } else {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => SubitemDetailPage(
                                    subitemId: s.id,
                                    title: s.title,
                                  ),
                                ),
                              );
                            }
                          },
                          onRename: () async {
                            final v = await promptText(context, title: 'Переименовать', initial: s.title);
                            if (v != null && v.isNotEmpty) {
                              await ref.read(repoProvider).renameSubitem(s.id, v);
                              if (mounted) setState(() {});
                            }
                          },
                          onDelete: () async {
                            final ok = await confirm(context, text: 'Удалить "${s.title}"?');
                            if (ok) {
                              await ref.read(repoProvider).deleteSubitem(s.id);
                              if (mounted) setState(() {});
                            }
                          },
                          onToggle: () => setState(() {}),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
