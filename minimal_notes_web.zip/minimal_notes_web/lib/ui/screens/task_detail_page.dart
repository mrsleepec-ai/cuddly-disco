
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models/subitem.dart';
import '../../services/repository.dart';
import '../../utils/dialogs.dart';
import '../widgets/subitem_tile.dart';
import 'subitem_detail_page.dart';
import 'home_page.dart';

class TaskDetailPage extends ConsumerStatefulWidget {
  final String taskId;
  final String taskTitle;
  final String? parentFolderId;

  const TaskDetailPage({super.key, required this.taskId, required this.taskTitle, this.parentFolderId});

  @override
  ConsumerState<TaskDetailPage> createState() => _TaskDetailPageState();
}

class _TaskDetailPageState extends ConsumerState<TaskDetailPage> {
  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(repoProvider);
    final atRoot = widget.parentFolderId == null;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.taskTitle, overflow: TextOverflow.ellipsis),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: FutureBuilder<List<Subitem>>(
        future: repo.listSubitems(taskId: widget.taskId, parentFolderId: widget.parentFolderId),
        builder: (context, snap) {
          final items = snap.data ?? const <Subitem>[];

          return Column(
            children: [
              // Header with task-level checkbox
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Row(
                  children: [
                    Checkbox(
                      value: ref.read(repoProvider).isTaskDone(widget.taskId),
                      onChanged: (v) async {
                        await ref.read(repoProvider).setTaskDone(widget.taskId, v ?? false);
                        if (mounted) setState(() {});
                      },
                    ),
                    const SizedBox(width: 8),
                    const Text('Задача выполнена'),
                    const Spacer(),
                    if (!atRoot)
                      TextButton.icon(
                        onPressed: () => Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (_) => TaskDetailPage(taskId: widget.taskId, taskTitle: widget.taskTitle, parentFolderId: null),
                        )),
                        icon: const Icon(Icons.home_outlined, size: 18),
                        label: const Text('К корню'),
                      ),
                  ],
                ),
              ),

              Expanded(
                child: snap.connectionState == ConnectionState.waiting
                    ? const Center(child: CircularProgressIndicator())
                    : items.isEmpty
                        ? const Center(child: Text('Нет элементов'))
                        : ListView.separated(
                            itemCount: items.length,
                            separatorBuilder: (_, __) => const Divider(height: 1),
                            itemBuilder: (ctx, i) {
                              final s = items[i];
                              final isFolder = s.type == SubitemType.folder;
                              final done = !isFolder && ref.read(repoProvider).isSubitemDone(s.id);

                              return SubitemTile(
                                subitem: s,
                                done: done,
                                onToggleDone: isFolder
                                    ? null
                                    : (v) async {
                                        final r = ref.read(repoProvider);
                                        await r.setSubitemDone(s.id, v);
                                        await r.recomputeTaskDoneFromSubs(widget.taskId);
                                        if (mounted) setState(() {});
                                      },
                                onOpen: () {
                                  if (isFolder) {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => TaskDetailPage(
                                          taskId: widget.taskId,
                                          taskTitle: widget.taskTitle,
                                          parentFolderId: s.id,
                                        ),
                                      ),
                                    );
                                  } else {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => SubitemDetailPage(subitemId: s.id, title: s.title),
                                      ),
                                    );
                                  }
                                },
                                onRename: () async {
                                  final v = await promptText(context, title: 'Переименовать', initial: s.title);
                                  if (v != null && v.isNotEmpty) {
                                    await ref.read(repoProvider).renameSubitem(s.id, v);
                                    if (mounted) setState(() {});
                                  }
                                },
                                onDelete: () async {
                                  final ok = await confirm(context, text: 'Удалить \"${s.title}\"?');
                                  if (ok) {
                                    await ref.read(repoProvider).deleteSubitem(s.id);
                                    await ref.read(repoProvider).recomputeTaskDoneFromSubs(widget.taskId);
                                    if (mounted) setState(() {});
                                  }
                                },
                              );
                            },
                          ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          // Добавить новую подзадачу в текущую папку
          final v = await promptText(context, title: 'Новая подзадача');
          if (v != null && v.trim().isNotEmpty) {
            await ref.read(repoProvider).createSubtask(widget.taskId, title: v.trim(), parentFolderId: widget.parentFolderId);
            if (mounted) setState(() {});
          }
        },
        icon: const Icon(Icons.add),
        label: const Text('Подзадача'),
      ),
    );
  }
}
