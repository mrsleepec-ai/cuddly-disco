import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models/task.dart';
import '../../services/repository.dart';
import '../../services/pdf_export.dart';
import '../../utils/dialogs.dart';
import '../widgets/task_tile.dart';
import 'task_detail_page.dart';

final repoProvider = ChangeNotifierProvider<Repo>((ref) => Repo());

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});

  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  final controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(repoProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Minimal Notes')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
            child: TextField(
              controller: controller,
              onSubmitted: (v) async {
                final text = v.trim();
                if (text.isEmpty) return;
                await ref.read(repoProvider).createTask(text);
                controller.clear();
                setState(() {});
              },
              decoration: InputDecoration(
                hintText: 'Новая задача...',
                suffixIcon: IconButton(
                  tooltip: 'Добавить',
                  icon: const Icon(Icons.add_circle_outline),
                  onPressed: () async {
                    final text = controller.text.trim();
                    if (text.isEmpty) return;
                    await ref.read(repoProvider).createTask(text);
                    controller.clear();
                    if (mounted) setState(() {});
                  },
                ),
              ),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Task>>(
              future: repo.listTasks(),
              builder: (context, snapshot) {
                final items = snapshot.data ?? const <Task>[];
                if (items.isEmpty) {
                  return const Center(child: Text('Список пуст'));
                }
                return ListView.builder(
                  itemCount: items.length,
                  itemBuilder: (ctx, i) {
                    final t = items[i];
                    return TaskTile(
                      task: t,
                      onOpen: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TaskDetailPage(taskId: t.id, taskTitle: t.title))),
                      onRename: () async {
                        final v = await promptText(context, title: 'Переименовать', initial: t.title);
                        if (v != null && v.isNotEmpty) {
                          await ref.read(repoProvider).renameTask(t.id, v);
                          setState(() {});
                        }
                      },
                      onPdfCompact: () async {
                        final exporter = PdfExporter();
                        await exporter.exportTask(t.id, PdfVariant.compact);
                      },
                      onPdfDetailed: () async {
                        final exporter = PdfExporter();
                        await exporter.exportTask(t.id, PdfVariant.detailed);
                      },
                      onDelete: () async {
                        final ok = await confirm(context, text: 'Удалить задачу "${t.title}"?');
                        if (ok) {
                          await ref.read(repoProvider).deleteTask(t.id);
                          setState(() {});
                        }
                      },
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
