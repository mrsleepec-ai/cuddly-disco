
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models/task.dart';
import '../../services/repository.dart';
import '../../services/pdf_export.dart';
import '../../utils/dialogs.dart';
import '../widgets/task_tile.dart';
import 'task_detail_page.dart';

final repoProvider = ChangeNotifierProvider<Repo>((ref) => Repo());

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});

  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  String _query = '';
  bool _centerComposer = false;
  final TextEditingController _centerCtl = TextEditingController();
  final FocusNode _centerFocus = FocusNode();

  void _openCenterComposer() {
    setState(() => _centerComposer = true);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_centerFocus.canRequestFocus) _centerFocus.requestFocus();
    });
  }

  Future<void> _submitCenter() async {
    final text = _centerCtl.text.trim();
    if (text.isNotEmpty) {
      await ref.read(repoProvider).createTask(text);
      if (mounted) setState(() {});
    }
    if (mounted) {
      setState(() {
        _centerComposer = false;
        _centerCtl.clear();
      });
    }
  }

  void _showSearch() {
    final ctl = TextEditingController(text: _query);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        top: false,
        child: AnimatedPadding(
          duration: const Duration(milliseconds: 150),
          curve: Curves.easeOut,
          padding: EdgeInsets.only(
            left: 16, right: 16, top: 16,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: ctl,
                  autofocus: true,
                  textInputAction: TextInputAction.search,
                  decoration: const InputDecoration(
                    hintText: 'Поиск по задачам',
                    prefixIcon: Icon(Icons.search),
                  ),
                  onChanged: (v) => setState(() => _query = v),
                  onSubmitted: (_) => Navigator.of(ctx).pop(),
                ),
                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () => Navigator.of(ctx).pop(),
                    child: const Text('Готово'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(repoProvider);
    return Scaffold(
      resizeToAvoidBottomInset: false,
      bottomNavigationBar: SafeArea(
        top: false,
        child: Container(
          height: 72,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)],
          ),
          child: Stack(
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: IconButton(
                  tooltip: 'Поиск',
                  icon: const Icon(Icons.search),
                  onPressed: _showSearch,
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: ElevatedButton(
                  onPressed: _openCenterComposer,
                  style: ElevatedButton.styleFrom(
                    shape: const CircleBorder(),
                    minimumSize: const Size(56, 56),
                    padding: EdgeInsets.zero,
                  ),
                  child: const Icon(Icons.add, size: 28),
                ),
              ),
            ],
          ),
        ),
      ),
      body: Stack(
        children: [
          // Основной контент
          FutureBuilder<List<Task>>(
            future: repo.listTasks(),
            builder: (context, snapshot) {
              final itemsAll = snapshot.data ?? const <Task>[];
              final q = _query.trim().toLowerCase();
              final items = q.isEmpty
                  ? itemsAll
                  : itemsAll.where((t) => t.title.toLowerCase().contains(q)).toList();
              final active = items.length;
              const done = 0;
              return Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                    child: Text(
                      'Активно $active / Выполнено $done',
                      style: Theme.of(context).textTheme.titleMedium,
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Expanded(
                    child: items.isEmpty
                        ? const Center(child: Text('Список пуст'))
                        : ListView.builder(
                            itemCount: items.length,
                            itemBuilder: (ctx, i) {
                              final t = items[i];
                              return TaskTile(
                                task: t,
                                onOpen: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => TaskDetailPage(taskId: t.id, taskTitle: t.title),
                                  ),
                                ),
                                onRename: () async {
                                  final v = await promptText(context, title: 'Переименовать', initial: t.title);
                                  if (v != null && v.isNotEmpty) {
                                    await ref.read(repoProvider).renameTask(t.id, v);
                                    if (mounted) setState(() {});
                                  }
                                },
                                onPdfCompact: () async {
                                  final exporter = PdfExporter();
                                  await exporter.exportTask(t.id, PdfVariant.compact);
                                },
                                onPdfDetailed: () async {
                                  final exporter = PdfExporter();
                                  await exporter.exportTask(t.id, PdfVariant.detailed);
                                },
                                onDelete: () async {
                                  final ok = await confirm(context, text: 'Удалить задачу "${t.title}"?');
                                  if (ok) {
                                    await ref.read(repoProvider).deleteTask(t.id);
                                    if (mounted) setState(() {});
                                  }
                                },
                              );
                            },
                          ),
                  ),
                ],
              );
            },
          ),

          // Центрированное окно ввода (закрытие по тапу вне)
          if (_centerComposer) ...[
            Positioned.fill(
              child: GestureDetector(
                onTap: () => setState(() => _centerComposer = false),
                child: Container(color: Colors.black38),
              ),
            ),
            Positioned.fill(
              child: SafeArea(
                child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 480),
                      child: Material(
                        elevation: 10,
                        borderRadius: BorderRadius.circular(16),
                        color: Theme.of(context).colorScheme.surface,
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              TextField(
                                controller: _centerCtl,
                                focusNode: _centerFocus,
                                autofocus: true,
                                textInputAction: TextInputAction.done,
                                decoration: const InputDecoration(hintText: 'Новая задача...'),
                                scrollPadding: EdgeInsets.zero,
                                onSubmitted: (_) => _submitCenter(),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
