import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models/task.dart';
import '../../services/repository.dart';
import '../../services/pdf_export.dart';
import '../../utils/dialogs.dart';
import '../widgets/task_tile.dart';
import 'task_detail_page.dart';

final repoProvider = ChangeNotifierProvider<Repo>((ref) => Repo());

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});

  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> with SingleTickerProviderStateMixin {
  final controller = TextEditingController();
  late final TabController tabs;

  @override
  void initState() {
    super.initState();
    tabs = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(repoProvider);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Minimal Notes'),
        bottom: TabBar(
          controller: tabs,
          tabs: const [
            Tab(text: 'Активные'),
            Tab(text: 'Выполненные'),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final text = controller.text.trim();
          if (text.isEmpty) {
            final v = await promptText(context, title: 'Название задачи');
            if (v == null || v.trim().isEmpty) return;
            await ref.read(repoProvider).createTask(v.trim());
          } else {
            await ref.read(repoProvider).createTask(text);
            controller.clear();
          }
          if (mounted) setState(() {});
        },
        child: const Icon(Icons.add),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
            child: TextField(
              controller: controller,
              onSubmitted: (v) async {
                final text = v.trim();
                if (text.isEmpty) return;
                await ref.read(repoProvider).createTask(text);
                controller.clear();
                setState(() {});
              },
              decoration: InputDecoration(
                hintText: 'Новая задача...',
                suffixIcon: IconButton(
                  tooltip: 'Добавить',
                  icon: const Icon(Icons.add_circle_outline),
                  onPressed: () async {
                    final text = controller.text.trim();
                    if (text.isEmpty) return;
                    await ref.read(repoProvider).createTask(text);
                    controller.clear();
                    if (mounted) setState(() {});
                  },
                ),
              ),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Task>>(
              future: repo.listTasks(),
              builder: (context, snapshot) {
                final all = snapshot.data ?? const <Task>[];
                final active = all.where((t) => !repo.isTaskCompletedSync(t.id)).toList();
                final done = all.where((t) => repo.isTaskCompletedSync(t.id)).toList();
                return TabBarView(
                  controller: tabs,
                  children: [
                    _buildList(context, active),
                    _buildList(context, done),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildList(BuildContext context, List<Task> items) {
    if (items.isEmpty) return const Center(child: Text('Список пуст'));
    return ListView.builder(
      itemCount: items.length,
      itemBuilder: (ctx, i) {
        final t = items[i];
        final isCompleted = ref.read(repoProvider).isTaskCompletedSync(t.id);
        return TaskTile(
          task: t,
          isCompleted: isCompleted,
          onOpen: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TaskDetailPage(taskId: t.id, taskTitle: t.title))),
          onToggle: (v) async {
            await ref.read(repoProvider).setTaskCompleted(t.id, v ?? false);
            setState(() {});
          },
          onRename: () async {
            final v = await promptText(context, title: 'Переименовать', initial: t.title);
            if (v != null && v.isNotEmpty) {
              await ref.read(repoProvider).renameTask(t.id, v);
              setState(() {});
            }
          },
          onPdfChecklist: () async {
            final days = await chooseDays(context);
            if (days == null) return;
            final exporter = PdfExporter();
            await exporter.exportTask(t.id, PdfVariant.checklist, days: days);
          },
          onPdfDetailed: () async {
            final exporter = PdfExporter();
            await exporter.exportTask(t.id, PdfVariant.detailed);
          },
          onDelete: () async {
            final ok = await confirm(context, text: 'Удалить задачу "${t.title}"?');
            if (ok) {
              await ref.read(repoProvider).deleteTask(t.id);
              setState(() {});
            }
          },
        );
      },
    );
  }
}
