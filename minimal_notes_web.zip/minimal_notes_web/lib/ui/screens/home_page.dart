import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../models/task.dart';
import '../../services/repository.dart';
import '../../services/pdf_export.dart';
import '../../utils/dialogs.dart';
import '../widgets/task_tile.dart';
import 'task_detail_page.dart';

final repoProvider = ChangeNotifierProvider<Repo>((ref) => Repo());

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});

  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  String _query = '';


void _showAddTask() {
  final ctl = TextEditingController();
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) {
      return SafeArea(
        top: false,
        child: AnimatedPadding(
          duration: const Duration(milliseconds: 150),
          curve: Curves.easeOut,
          padding: EdgeInsets.only(
            left: 16, right: 16, top: 16,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: ctl,
              autofocus: true,
              decoration: const InputDecoration(hintText: 'Новая задача...'),
              onSubmitted: (_) async {
                final text = ctl.text.trim();
                if (text.isEmpty) return;
                await ref.read(repoProvider).createTask(text);
                if (mounted) setState(() {});
                Navigator.of(context).pop();
              },
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () async {
                final text = ctl.text.trim();
                if (text.isEmpty) return;
                await ref.read(repoProvider).createTask(text);
                if (mounted) setState(() {});
                Navigator.of(context).pop();
              },
              child: const Text('Добавить'),
            ),
          ],
        ),
      );
    },
  );
}

void _showSearch() {
  final ctl = TextField(
    autofocus: true,
    decoration: InputDecoration(
      hintText: 'Поиск по задачам',
      prefixIcon: const Icon(Icons.search),
      suffixIcon: _query.isEmpty
          ? null
          : IconButton(
              icon: const Icon(Icons.clear),
              onPressed: () {
                setState(() => _query = '');
                Navigator.of(context).pop();
              },
            ),
    ),
    onChanged: (v) => setState(() => _query = v),
    onSubmitted: (_) => Navigator.of(context).pop(),
  );

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (_) => Padding(
      padding: EdgeInsets.only(
        left: 16, right: 16, top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ctl,
          const SizedBox(height: 12),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Готово'),
            ),
          ),
        ],
      ),
    ),
  );
}

  final controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(repoProvider);
    return Scaffold(
      resizeToAvoidBottomInset: false,
      

bottomNavigationBar: SafeArea(
  top: false,
  child: Container(
    height: 72,
    padding: const EdgeInsets.symmetric(horizontal: 12),
    decoration: BoxDecoration(
      color: Theme.of(context).colorScheme.surface,
      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)],
    ),
    child: Stack(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: IconButton(
            tooltip: 'Поиск',
            icon: const Icon(Icons.search),
            onPressed: _showSearch,
          ),
        ),
        Align(
          alignment: Alignment.center,
          child: ElevatedButton(
            onPressed: _showAddTask,
            style: ElevatedButton.styleFrom(
              shape: const CircleBorder(),
              minimumSize: const Size(56, 56),
              padding: EdgeInsets.zero,
            ),
            child: const Icon(Icons.add, size: 28),
          ),
        ),
      ],
    ),
  ),
),
body: Column(
        children: [
          FutureBuilder<List<Task>>(
            future: repo.listTasks(),
            builder: (context, snapshot) {
              final items0 = snapshot.data ?? const <Task>[];
                final q = _query.trim().toLowerCase();
                final items = q.isEmpty ? items0 : items0.where((t) => t.title.toLowerCase().contains(q)).toList();
              final active = items.length; // модель Task не имеет поля done
              final done = 0;
              return Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Text('Активно '+active.toString()+' / Выполнено '+done.toString(),
                    style: Theme.of(context).textTheme.titleMedium,
                    textAlign: TextAlign.center),
              );
            },
          ),
          SizedBox(height: 0),
          Expanded(
            child: FutureBuilder<List<Task>>(
              future: repo.listTasks(),
              builder: (context, snapshot) {
                final items0 = snapshot.data ?? const <Task>[];
                final q = _query.trim().toLowerCase();
                final items = q.isEmpty ? items0 : items0.where((t) => t.title.toLowerCase().contains(q)).toList();
                if (items.isEmpty) {
                  return const Center(child: Text('Список пуст'));
                }
                return ListView.builder(
                  itemCount: items.length,
                  itemBuilder: (ctx, i) {
                    final t = items[i];
                    return TaskTile(
                      task: t,
                      onOpen: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TaskDetailPage(taskId: t.id, taskTitle: t.title))),
                      onRename: () async {
                        final v = await promptText(context, title: 'Переименовать', initial: t.title);
                        if (v != null && v.isNotEmpty) {
                          await ref.read(repoProvider).renameTask(t.id, v);
                          setState(() {});
                        }
                      },
                      onPdfCompact: () async {
                        final exporter = PdfExporter();
                        await exporter.exportTask(t.id, PdfVariant.compact);
                      },
                      onPdfDetailed: () async {
                        final exporter = PdfExporter();
                        await exporter.exportTask(t.id, PdfVariant.detailed);
                      },
                      onDelete: () async {
                        final ok = await confirm(context, text: 'Удалить задачу "${t.title}"?');
                        if (ok) {
                          await ref.read(repoProvider).deleteTask(t.id);
                          setState(() {});
                        }
                      },
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
