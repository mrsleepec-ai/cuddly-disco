import 'package:flutter/material.dart';

Future<String?> promptText(BuildContext context, {required String title, String? initial}) async {
  final controller = TextEditingController(text: initial ?? '');
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: controller,
        autofocus: true,
        decoration: const InputDecoration(hintText: 'Введите текст'),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Отмена')),
        FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('OK')),
      ],
    ),
  );
}

Future<bool> confirm(BuildContext context, {required String text}) async {
  return (await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          content: Text(text),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Нет')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Да')),
          ],
        ),
      )) ??
      false;
}

Future<int?> chooseDays(BuildContext context) async {
  return showDialog<int>(
    context: context,
    builder: (ctx) => SimpleDialog(
      title: const Text('Чек-лист: за сколько дней?'),
      children: [
        SimpleDialogOption(onPressed: () => Navigator.pop(ctx, 7), child: const Text('7 дней')),
        SimpleDialogOption(onPressed: () => Navigator.pop(ctx, 14), child: const Text('14 дней')),
        SimpleDialogOption(onPressed: () => Navigator.pop(ctx, 21), child: const Text('21 день')),
        SimpleDialogOption(onPressed: () => Navigator.pop(ctx, 28), child: const Text('28 дней (4 недели)')),
      ],
    ),
  );
}

Future<String?> chooseFolder(BuildContext context, {required String title, required List<(String id, String label)> options}) async {
  return showDialog<String>(
    context: context,
    builder: (ctx) => SimpleDialog(
      title: Text(title),
      children: [
        SimpleDialogOption(
          onPressed: () => Navigator.pop(ctx, 'root'),
          child: const Text('Корень (вне папок)'),
        ),
        const Divider(height: 1),
        ...options.map((o) => SimpleDialogOption(
          onPressed: () => Navigator.pop(ctx, o.$1),
          child: Text(o.$2),
        ))
      ],
    ),
  );
}
