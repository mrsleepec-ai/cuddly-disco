import 'package:flutter/material.dart';

Future<String?> promptText(BuildContext context, {required String title, String? initial}) async {
  final controller = TextEditingController(text: initial ?? '');
  return showDialog<String>(
    context: context,
    barrierDismissible: true,
    useSafeArea: true,
    builder: (ctx) {
      final bottom = MediaQuery.of(ctx).viewInsets.bottom;
      return Dialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: AnimatedPadding(
          duration: const Duration(milliseconds: 150),
          curve: Curves.easeOut,
          padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: bottom + 16),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(title, style: Theme.of(ctx).textTheme.titleMedium),
                const SizedBox(height: 12),
                TextField(
                  controller: controller,
                  autofocus: true,
                  scrollPadding: const EdgeInsets.all(0),
                  decoration: const InputDecoration(hintText: 'Введите текст'),
                  onSubmitted: (_) => Navigator.pop(ctx, controller.text.trim()),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Отмена')),
                    const SizedBox(width: 8),
                    FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('OK')),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

Future<bool> confirm(BuildContext context, {required String text}) async {
  return (await showDialog<bool>(
        context: context,
        barrierDismissible: true,
        useSafeArea: true,
        builder: (ctx) {
          final bottom = MediaQuery.of(ctx).viewInsets.bottom;
          return Dialog(
            insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: AnimatedPadding(
              duration: const Duration(milliseconds: 150),
              curve: Curves.easeOut,
              padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: bottom + 16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(text),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Нет')),
                      const SizedBox(width: 8),
                      FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Да')),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      )) ??
      false;
}
