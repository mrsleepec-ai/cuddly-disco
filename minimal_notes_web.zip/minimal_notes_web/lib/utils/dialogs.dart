// ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;

void _ensureKeyboardShownForIOSWeb() {
  if (!kIsWeb) return;
  if (defaultTargetPlatform != TargetPlatform.iOS) return;
  final el = html.InputElement();
  el.style.position = 'fixed';
  el.style.opacity = '0';
  el.style.bottom = '0';
  el.autofocus = true;
  html.document.body?.append(el);
  el.focus();
  Future.delayed(const Duration(milliseconds: 100), () {
    el.remove();
  });
}

import 'package:flutter/foundation.dart' show kIsWeb, defaultTargetPlatform, TargetPlatform;
import 'package:flutter/material.dart';

Future<String?> promptText(BuildContext context, {required String title, String? initial}) async {
  _ensureKeyboardShownForIOSWeb();
final ctl = TextEditingController(text: initial ?? '');
  final focus = FocusNode();

  final result = await showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) {
      // Отложенный фокус, чтобы iOS Web не срывал его во время анимации
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!focus.hasFocus) focus.requestFocus();
      });

      final bottom = MediaQuery.of(ctx).viewInsets.bottom;

      // Убираем дефолтные инсерты у шита и сами поднимаем карточку на высоту клавиатуры.
      return MediaQuery.removeViewInsets(
        removeBottom: true,
        context: ctx,
        child: SafeArea(
          top: false,
          child: Stack(
            children: [
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: Padding(
                  padding: EdgeInsets.only(left: 16, right: 16, bottom: bottom + 12),
                  child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 560),
                      child: Material(
                        elevation: 8,
                        color: Theme.of(ctx).colorScheme.surface,
                        borderRadius: const BorderRadius.all(Radius.circular(16)),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            mainAxisSize: MainAxisSize.min, // <— маленькая карточка
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Text(title, style: Theme.of(ctx).textTheme.titleMedium),
                              const SizedBox(height: 12),
                              TextField(
                                controller: ctl,
                                focusNode: focus,
                                autofocus: true,
                                textInputAction: TextInputAction.done,
                                onSubmitted: (_) => Navigator.pop(ctx, ctl.text.trim()),
                                decoration: const InputDecoration(hintText: 'Введите текст'),
                              ),
                              const SizedBox(height: 12),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Отмена')),
                                  const SizedBox(width: 8),
                                  FilledButton(onPressed: () => Navigator.pop(ctx, ctl.text.trim()), child: const Text('ОК')),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );

  focus.dispose();
  ctl.dispose();
  return result;
}

Future<bool> confirm(BuildContext context, {required String text}) async {
  final result = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) {
      final bottom = MediaQuery.of(ctx).viewInsets.bottom;
      return MediaQuery.removeViewInsets(
        removeBottom: true,
        context: ctx,
        child: SafeArea(
          top: false,
          child: Stack(
            children: [
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: Padding(
                  padding: EdgeInsets.only(left: 16, right: 16, bottom: bottom + 12),
                  child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 560),
                      child: Material(
                        elevation: 8,
                        color: Theme.of(ctx).colorScheme.surface,
                        borderRadius: const BorderRadius.all(Radius.circular(16)),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Text(text),
                              const SizedBox(height: 12),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Нет')),
                                  const SizedBox(width: 8),
                                  FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Да')),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
  return result ?? false;
}
