import 'package:flutter/material.dart';


Future<String?> promptText(BuildContext context, {required String title, String? initial}) async {
  final controller = TextEditingController(text: initial ?? '');
  final focus = FocusNode();
  return showDialog<String>(
    context: context,
    barrierDismissible: true,
    useSafeArea: true,
    builder: (ctx) {
      void focusIt() {
        if (focus.canRequestFocus) focus.requestFocus();
      }
      WidgetsBinding.instance.addPostFrameCallback((_) {
        focusIt();
        Future.microtask(focusIt);
        Future.delayed(const Duration(milliseconds: 30), focusIt);
        Future.delayed(const Duration(milliseconds: 80), focusIt);
        Future.delayed(const Duration(milliseconds: 160), focusIt);
      });

      return Dialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(title, style: Theme.of(ctx).textTheme.titleMedium),
              const SizedBox(height: 12),
              TextField(
                controller: controller,
                focusNode: focus,
                autofocus: true,
                textInputAction: TextInputAction.done,
                scrollPadding: EdgeInsets.zero,
                onSubmitted: (_) => Navigator.pop(ctx, controller.text.trim()),
                decoration: const InputDecoration(
                  hintText: 'Введите текст',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(onPressed: () => Navigator.pop(ctx, null), child: const Text('Отмена')),
                  const SizedBox(width: 8),
                  FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('OK')),
                ],
              ),
            ],
          ),
        ),
      );
    },
  );
}

Future<bool> confirm(BuildContext context, {required String text}) async {
  return (await showDialog<bool>(
        context: context,
        barrierDismissible: true,
        useSafeArea: true,
        builder: (ctx) {
          final bottom = MediaQuery.of(ctx).viewInsets.bottom;
          return Dialog(
            insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: AnimatedPadding(
              duration: const Duration(milliseconds: 150),
              curve: Curves.easeOut,
              padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: bottom + 16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(text),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Нет')),
                      const SizedBox(width: 8),
                      FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Да')),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      )) ??
      false;
}
