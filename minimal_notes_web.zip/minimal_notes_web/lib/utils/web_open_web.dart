import 'dart:typed_data';
import 'dart:html' as html;

abstract class WebOpen {
  static Future<void> openBytes(Uint8List bytes, String mime, String filename) async {
    final blob = html.Blob([bytes], mime);
    final url = html.Url.createObjectUrlFromBlob(blob);
    final anchor = html.AnchorElement(href: url)
      ..download = filename
      ..target = '_blank';
    anchor.click();
    html.Url.revokeObjectUrl(url);
  }
}
