import 'dart:typed_data';

abstract class WebOpen {
  static Future<void> openBytes(Uint8List bytes, String mime, String filename) async {
    // no-op on non-web builds
  }
}
