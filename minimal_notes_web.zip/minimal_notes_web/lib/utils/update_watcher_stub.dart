class UpdateWatcher {
  void start({Duration interval = const Duration(seconds: 60)}) {}
  void dispose() {}
}
