import 'dart:async';
import 'dart:convert';
import 'dart:html' as html;

class UpdateWatcher {
  String? _current;
  Timer? _timer;

  void start({Duration interval = const Duration(seconds: 60)}) {
    // first check quickly, потом периодически
    _check();
    _timer = Timer.periodic(interval, (_) => _check());
  }

  Future<void> _check() async {
    try {
      final url = 'version.json?nocache=${DateTime.now().millisecondsSinceEpoch}';
      final resp = await html.HttpRequest.request(url, method: 'GET', requestHeaders: {'Cache-Control': 'no-cache'});
      if (resp.status == 200 && resp.responseText != null) {
        final data = jsonDecode(resp.responseText!);
        final v = (data['version'] ?? '').toString();
        if (_current == null) {
          _current = v;
        } else if (v.isNotEmpty && _current != v) {
          // новая версия на сервере
          html.window.location.reload();
        }
      }
    } catch (_) {
      // ignore network errors silently
    }
  }

  void dispose() {
    _timer?.cancel();
  }
}
