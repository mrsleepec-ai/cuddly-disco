import 'package:flutter/material.dart';
import '../../models/subitem.dart';
import '../../utils/dialogs.dart';

class SubitemTile extends StatelessWidget {
  final Subitem subitem;
  final VoidCallback onOpen;
  final VoidCallback onRename;
  final VoidCallback onDelete;
  final VoidCallback? onToggle; // сообщаем родителю о смене чекбокса

  const SubitemTile({
    super.key,
    required this.subitem,
    required this.onOpen,
    required this.onRename,
    required this.onDelete,
    this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onOpen,
      leading: subitem.isFolder
          ? const Icon(Icons.folder)
          : Checkbox(
              value: subitem.isChecked,
              onChanged: (v) async {
                // оптимистично обновляем значение
                subitem.isChecked = v ?? false;
                await subitem.save();
                // уведомляем родителя, чтобы он пересобрался и подтянул актуальные данные
                onToggle?.call();
              },
            ),
      title: Text(subitem.title),
      subtitle: subitem.isSubtask && (subitem.note?.isNotEmpty == true)
          ? Text(subitem.note!)
          : null,
      trailing: 
IconButton(
  icon: const Icon(Icons.more_vert),
  onPressed: () async {
    // Открываем собственное меню действия
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Material(
              elevation: 8,
              borderRadius: const BorderRadius.all(Radius.circular(12)),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ListTile(
                    leading: const Icon(Icons.edit),
                    title: const Text('Переименовать'),
                    onTap: () {
                      // ВАЖНО: триггер клавиатуры в рамках этого же тапа
                      ensureKeyboardOnUserTap();
                      Navigator.pop(ctx);
                      // После закрытия меню запускаем действие
                      Future.microtask(onRename);
                    },
                  ),
                  const Divider(height: 0),
                  ListTile(
                    leading: const Icon(Icons.delete_outline),
                    title: const Text('Удалить'),
                    onTap: () {
                      Navigator.pop(ctx);
                      Future.microtask(onDelete);
                    },
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  },
),
}
