import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'models/task.dart';
import 'models/subitem.dart';
import 'models/attachment.dart';
import 'ui/screens/home_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
  };

  try {
    await Hive.initFlutter();
    Hive.registerAdapter(TaskAdapter());
    Hive.registerAdapter(SubitemTypeAdapter());
    Hive.registerAdapter(SubitemAdapter());
    Hive.registerAdapter(AttachmentAdapter());
    await Hive.openBox<Task>('tasks');
    await Hive.openBox<Subitem>('subitems');
    await Hive.openBox<Attachment>('attachments');
    runApp(const ProviderScope(child: MyApp()));
  } catch (e, st) {
    runApp(ErrorScreen(e, st));
  }
}

class ErrorScreen extends StatelessWidget {
  final Object error;
  final StackTrace? stack;
  const ErrorScreen(this.error, [this.stack], {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: const Color(0xFFF8F9FB),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 560),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Не удалось инициализировать хранилище', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 12),
                    const Text('На iOS/Safari это чаще всего бывает из‑за приватного режима или повреждённого кэша. '
                        'Попробуйте: выйти из приватного режима, очистить "Website Data" для этого сайта, '
                        'или открыть ссылку в обычном Safari.',
                        style: TextStyle(fontSize: 14, height: 1.35)),
                    const SizedBox(height: 12),
                    Text(error.toString(), style: const TextStyle(color: Colors.black54)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Minimal Notes Web',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blueGrey,
        scaffoldBackgroundColor: const Color(0xFFF8F9FB),
        appBarTheme: const AppBarTheme(centerTitle: true, elevation: 0),
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(borderSide: BorderSide.none),
          filled: true,
          fillColor: Colors.white,
          contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        ),
        listTileTheme: const ListTileThemeData(iconColor: Colors.black87),
      ),
      home: const HomePage(),
    );
  }
}
