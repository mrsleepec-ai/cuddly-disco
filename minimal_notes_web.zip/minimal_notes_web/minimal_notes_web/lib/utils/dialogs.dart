// ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;
import 'dart:async';

import 'package:flutter/foundation.dart' show kIsWeb, defaultTargetPlatform, TargetPlatform;
import 'package:flutter/material.dart';

/// iOS Safari hack: в том же жесте пользователя фокусируем невидимый <input>,
/// чтобы гарантированно поднять клавиатуру ДО открытия нашего шита.
void _ensureKeyboardShownForIOSWeb() {
  if (!kIsWeb) return;
  if (defaultTargetPlatform != TargetPlatform.iOS) return;
  final el = html.InputElement();
  el.style.position = 'fixed';
  el.style.opacity = '0';
  el.style.bottom = '0';
  el.autofocus = true;
  html.document.body?.append(el);
  el.focus();
  Future.delayed(const Duration(milliseconds: 100), () { el.remove(); });
}

Future<String?> promptText(BuildContext context, {required String title, String? initial}) async {
  ensureKeyboardOnUserTap(); // триггерим клавиатуру сразу на тап по кнопке

  final result = await showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) {
      return _PromptCard(
        title: title,
        initial: initial ?? '',
        onOk: (value) => Navigator.pop(ctx, value),
        onCancel: () => Navigator.pop(ctx),
      );
    },
  );
  return result;
}

Future<bool> confirm(BuildContext context, {required String text}) async {
  final result = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) {
      return _ConfirmCard(
        text: text,
        onYes: () => Navigator.pop(ctx, true),
        onNo: () => Navigator.pop(ctx, false),
      );
    },
  );
  return result ?? false;
}

class _PromptCard extends StatefulWidget {
  final String title;
  final String initial;
  final ValueChanged<String> onOk;
  final VoidCallback onCancel;

  const _PromptCard({
    required this.title,
    required this.initial,
    required this.onOk,
    required this.onCancel,
  });

  @override
  State<_PromptCard> createState() => _PromptCardState();
}

class _PromptCardState extends State<_PromptCard> {
  late final TextEditingController _ctl;
  final FocusNode _focus = FocusNode();
  Timer? _retryTimer;

  @override
  void initState() {
    super.initState();
    _ctl = TextEditingController(text: widget.initial);

    // Несколько попыток сфокусировать поле, чтобы iOS Web точно поднял клавиатуру.
    Future.microtask(() { if (mounted) _focus.requestFocus(); });
    WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted) _focus.requestFocus(); });
    _retryTimer = Timer(const Duration(milliseconds: 220), () {
      if (mounted && !_focus.hasFocus) _focus.requestFocus();
    });
  }

  @override
  void dispose() {
    _retryTimer?.cancel();
    _ctl.dispose();
    _focus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;

    return MediaQuery.removeViewInsets(
      removeBottom: true,
      context: context,
      child: SafeArea(
        top: false,
        child: Stack(
          children: [
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Padding(
                padding: EdgeInsets.only(left: 16, right: 16, bottom: bottom + 12),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 560),
                    child: Material(
                      elevation: 8,
                      color: Theme.of(context).colorScheme.surface,
                      borderRadius: const BorderRadius.all(Radius.circular(16)),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(widget.title, style: Theme.of(context).textTheme.titleMedium),
                            const SizedBox(height: 12),
                            TextField(
                              controller: _ctl,
                              focusNode: _focus,
                              autofocus: true,
                              textInputAction: TextInputAction.done,
                              onSubmitted: (_) => widget.onOk(_ctl.text.trim()),
                              decoration: const InputDecoration(hintText: 'Введите текст'),
                            ),
                            const SizedBox(height: 12),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                TextButton(onPressed: widget.onCancel, child: const Text('Отмена')),
                                const SizedBox(width: 8),
                                FilledButton(onPressed: () => widget.onOk(_ctl.text.trim()), child: const Text('ОК')),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ConfirmCard extends StatelessWidget {
  final String text;
  final VoidCallback onYes;
  final VoidCallback onNo;

  const _ConfirmCard({required this.text, required this.onYes, required this.onNo});

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;

    return MediaQuery.removeViewInsets(
      removeBottom: true,
      context: context,
      child: SafeArea(
        top: false,
        child: Stack(
          children: [
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Padding(
                padding: EdgeInsets.only(left: 16, right: 16, bottom: bottom + 12),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 560),
                    child: Material(
                      elevation: 8,
                      color: Theme.of(context).colorScheme.surface,
                      borderRadius: const BorderRadius.all(Radius.circular(16)),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(text),
                            const SizedBox(height: 12),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                TextButton(onPressed: onNo, child: const Text('Нет')),
                                const SizedBox(width: 8),
                                FilledButton(onPressed: onYes, child: const Text('Да')),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

void _tryShowVirtualKeyboard() {
  // Try Chrome/Android Virtual Keyboard API, ignore if unsupported.
  try {
    // ignore: undefined_prefixed_name
    final vk = (html.window.navigator as dynamic).virtualKeyboard;
    if (vk != null) {
      (vk as dynamic).show();
    }
  } catch (_) {
    // no-op
  }
}

/// Call this at the very start of any onPressed/onTap that should immediately bring up the keyboard.
void ensureKeyboardOnUserTap() {
  _ensureKeyboardShownForIOSWeb();
  _tryShowVirtualKeyboard();
}
