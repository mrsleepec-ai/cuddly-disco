// GENERATED CODE - MANUAL (no build_runner)
part of 'subitem.dart';

class SubitemTypeAdapter extends TypeAdapter<SubitemType> {
  @override
  final int typeId = 2;

  @override
  SubitemType read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return SubitemType.folder;
      case 1:
        return SubitemType.subtask;
      default:
        return SubitemType.subtask;
    }
  }

  @override
  void write(BinaryWriter writer, SubitemType obj) {
    switch (obj) {
      case SubitemType.folder:
        writer.writeByte(0);
        break;
      case SubitemType.subtask:
        writer.writeByte(1);
        break;
    }
  }
}

class SubitemAdapter extends TypeAdapter<Subitem> {
  @override
  final int typeId = 3;

  @override
  Subitem read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{};
    for (int i = 0; i < numOfFields; i++) {
      fields[reader.readByte()] = reader.read();
    }
    return Subitem(
      id: fields[0] as String,
      taskId: fields[1] as String,
      parentFolderId: fields[2] as String?,
      type: fields[3] as SubitemType,
      title: fields[4] as String,
      note: fields[5] as String?,
      createdAt: fields[6] as DateTime,
      isChecked: (fields[7] as bool?) ?? false,
    );
  }

  @override
  void write(BinaryWriter writer, Subitem obj) {
    writer
      ..writeByte(8) // total number of fields
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.taskId)
      ..writeByte(2)
      ..write(obj.parentFolderId)
      ..writeByte(3)
      ..write(obj.type)
      ..writeByte(4)
      ..write(obj.title)
      ..writeByte(5)
      ..write(obj.note)
      ..writeByte(6)
      ..write(obj.createdAt)
      ..writeByte(7)
      ..write(obj.isChecked);
  }
}
