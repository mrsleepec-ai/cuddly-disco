import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:hive/hive.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:uuid/uuid.dart';
import '../models/task.dart';
import '../models/subitem.dart';
import '../models/attachment.dart';

class Repo extends ChangeNotifier {
  final _uuid = const Uuid();
  Box<Task> get _tasks => Hive.box<Task>('tasks');
  Box<Subitem> get _subs => Hive.box<Subitem>('subitems');
  Box<Attachment> get _atts => Hive.box<Attachment>('attachments');

  Future<List<Task>> listTasks() async {
    final items = _tasks.values.toList();
    items.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return items;
  }

  Future<Task> createTask(String title) async {
    final t = Task(id: _uuid.v4(), title: title.trim(), createdAt: DateTime.now());
    await _tasks.put(t.id, t);
    notifyListeners();
    return t;
  }

  Future<void> renameTask(String id, String newTitle) async {
    final t = _tasks.get(id);
    if (t != null) {
      t.title = newTitle.trim();
      await t.save();
      notifyListeners();
    }
  }

  Future<void> deleteTask(String id) async {
    final subsToDelete = _subs.values.where((s) => s.taskId == id).map((s) => s.id).toList();
    final attsToDelete = _atts.values.where((a) => subsToDelete.contains(a.subitemId)).map((a)=>a.id).toList();
    await _atts.deleteAll(attsToDelete);
    await _subs.deleteAll(subsToDelete);
    await _tasks.delete(id);
    notifyListeners();
  }

  Future<List<Subitem>> listSubitems({required String taskId, String? parentFolderId}) async {
    final items = _subs.values.where((s) => s.taskId == taskId && s.parentFolderId == parentFolderId).toList();
    items.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return items;
  }

  Future<Subitem> createFolder(String taskId, {String? parentFolderId, required String title}) async {
    final s = Subitem(
      id: _uuid.v4(),
      taskId: taskId,
      parentFolderId: parentFolderId,
      type: SubitemType.folder,
      title: title.trim(),
      note: null,
      createdAt: DateTime.now(),
    );
    await _subs.put(s.id, s);
    notifyListeners();
    return s;
  }

  Future<Subitem> createSubtask(String taskId, {String? parentFolderId, required String title}) async {
    final s = Subitem(
      id: _uuid.v4(),
      taskId: taskId,
      parentFolderId: parentFolderId,
      type: SubitemType.subtask,
      title: title.trim(),
      note: '',
      createdAt: DateTime.now(),
    );
    await _subs.put(s.id, s);
    notifyListeners();
    return s;
  }

  Future<void> renameSubitem(String id, String newTitle) async {
    final s = _subs.get(id);
    if (s != null) {
      s.title = newTitle.trim();
      await s.save();
      notifyListeners();
    }
  }

  Future<void> deleteSubitem(String id) async {
    final toDelete = _collectNested(id);
    final attIds = _atts.values.where((a) => toDelete.contains(a.subitemId)).map((a)=>a.id).toList();
    await _atts.deleteAll(attIds);
    await _subs.deleteAll(toDelete);
    notifyListeners();
  }

  Set<String> _collectNested(String rootId) {
    final set = <String>{rootId};
    bool changed = true;
    while (changed) {
      changed = false;
      for (final s in _subs.values) {
        if (s.parentFolderId != null && set.contains(s.parentFolderId)) {
          if (set.add(s.id)) changed = true;
        }
      }
    }
    return set;
  }

  Future<Subitem?> readSubitem(String id) async => _subs.get(id);

  Future<void> updateNote(String subitemId, String note) async {
    final s = _subs.get(subitemId);
    if (s != null) {
      s.note = note;
      await s.save();
      notifyListeners();
    }
  }

  Future<List<Attachment>> listAttachments(String subitemId) async {
    final list = _atts.values.where((a) => a.subitemId == subitemId).toList();
    list.sort((a,b)=> b.createdAt.compareTo(a.createdAt));
    return list;
  }

  Future<Attachment> addAttachment({
    required String subitemId,
    required String filename,
    required String mimeType,
    required Uint8List bytes,
  }) async {
    final a = Attachment(
      id: _uuid.v4(),
      subitemId: subitemId,
      filename: filename,
      mimeType: mimeType,
      bytes: bytes,
      createdAt: DateTime.now(),
    );
    await _atts.put(a.id, a);
    notifyListeners();
    return a;
  }

  Future<void> removeAttachment(String id) async {
    await _atts.delete(id);
    notifyListeners();
  }

  // Synchronous accessors for UI to rebuild instantly on notifyListeners
  List<Subitem> subitemsSync({required String taskId, String? parentFolderId}) {
    final items = _subs.values.where((s) => s.taskId == taskId && s.parentFolderId == parentFolderId).toList();
    items.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return items;
  }

  Subitem? getSubitemSync(String id) => _subs.get(id);
}




// Global Riverpod provider for Repo
final repoProvider = ChangeNotifierProvider<Repo>((ref) => Repo());
