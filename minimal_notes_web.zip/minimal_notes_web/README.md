# Minimal Notes Web (Flutter Web)

Веб-версия приложения (IndexedDB через Hive), готовая к деплою на **GitHub Pages**.

## Возможности
- Главный экран: список задач + поле создания новой.
- Для задачи: переименовать, удалить, экспорт в PDF (**compact** / **detailed**).
- Экран задачи: папки (вложенные уровни) и подзадачи.
- Экран подзадачи: заметка + вложения (камера, галерея, файлы) — хранятся в IndexedDB.
- Открытие вложений: скачивание/просмотр через Blob URL в новой вкладке.
- Экспорт PDF: генерируется в памяти и скачивается/открывается пользователю.

## Запуск локально
```bash
flutter pub get
flutter run -d chrome
```

## Деплой на GitHub Pages
> Если приложение будет по адресу `https://<user>.github.io/<repo>/`, используйте `--base-href /<repo>/`

1) Собрать релиз:
```bash
flutter build web --release --base-href /<repo>/
```
2) Задеплоить содержимое `build/web` в ветку `gh-pages`:
```bash
git init
git remote add origin https://github.com/<user>/<repo>.git
git checkout -b gh-pages
cp -r build/web/* .
git add .
git commit -m "deploy"
git push -u origin gh-pages
```
3) В настройках репозитория включить **Pages** → Branch: `gh-pages` → `/ (root)`.

Готов адаптировать PDF в точности под старые шаблоны (если пришлёте пример). Также могу добавить чекбоксы, сортировку, поиск и т.д.
