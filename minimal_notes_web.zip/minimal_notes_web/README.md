# Minimal Notes Web — v3

- PDF **Чек-лист**: таблица с подзадачами по строкам и датами по столбцам, начиная со дня создания задачи. Перед экспортом выбираете период (7/14/21/28 дней).
- PDF **Полный перечень**: все подзадачи по порядку, с заметками и встроенными миниатюрами изображений.
- Остальное: сортировка по возрастанию (новое внизу), перемещение подзадач в папки, предпросмотр фото, чекбоксы и вкладка «Выполненные».


## Авто-обновление (перезагрузка при деплое)
В workflow добавьте шаг, создающий `version.json` с SHA коммита — приложение будет проверять этот файл и автоматически перезагружаться при публикации новой версии.

```yaml
      - name: Write version.json
        working-directory: minimal_notes_web
        run: |
          mkdir -p build/web
          echo "{"version":"${GITHUB_SHA}"}" > build/web/version.json
```

(Этот шаг должен идти **после** `flutter build web`, но **до** деплоя на gh-pages.)


## Шрифты для PDF (встроенные)
PDF использует Noto Sans (кириллица), берёт TTF из `assets/fonts/`.
Если файлов нет в репозитории, workflow может скачать их автоматически:

```yaml
- name: Download NotoSans fonts
  working-directory: minimal_notes_web
  run: |
    mkdir -p assets/fonts
    curl -L -o assets/fonts/NotoSans-Regular.ttf https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/notosans/NotoSans-Regular.ttf
    curl -L -o assets/fonts/NotoSans-Bold.ttf https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/notosans/NotoSans-Bold.ttf
```
