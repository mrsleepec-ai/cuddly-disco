# Minimal Notes Web (Flutter Web)

Веб-версия приложения (IndexedDB через Hive), готовая к деплою на **GitHub Pages**.

## Быстрый деплой с телефона (через GitHub Actions)
- Загрузите архив `minimal_notes_web.zip` в корень репозитория.
- Создайте файл `.github/workflows/deploy.yml` (см. инструкцию в чате).
- Actions соберёт и опубликует сайт в ветку `gh-pages`.

## Локальный запуск
```bash
flutter pub get
flutter run -d chrome
```

## Особенности
- Добавлена большая **кнопка «+»** и «плюс» в поле ввода для создания задач.
- Исправлена совместимость с `file_picker` 8.x (определение MIME по расширению).
